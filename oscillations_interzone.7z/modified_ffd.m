function [Frq,phi,filtered_signal]=FDD(Input,Fs,input_type)

%%Copyright (c) 2015, Mohammad Farshchin
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
% 
% * Redistributions of source code must retain the above copyright notice, this
%   list of conditions and the following disclaimer.
% 
% * Redistributions in binary form must reproduce the above copyright notice,
%   this list of conditions and the following disclaimer in the documentation
%   and/or other materials provided with the distribution
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
% DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%% Frequency Domain Decomposition (FDD) algorithm for modal analysis
% This code allows you to manually select the peaks by simply drawing a
% rectangle around the peaks.
% Programmer: Mohammad Farshchin, Ph.D candidate at The UofM
% Email: Mohammad.Farshchin@gmail.com
% Last modified: 4/6/2015

% Modified by Skrolan Endrass 2018-09-06

% Input: the name of input file that contains time history data
% Fs: sampling frequency
% Frq: identified frequencies
% phi: identified mode shapes
% Example: [Frq,phi]=FDD('Accelerations.xlsx',500);

% For detailed information about this method see: Brincker R, Zhang LM, Andersen P. Modal identification from ambient responses using Frequency Domain Decomposition. In: Proceedings of the 18th International Modal Analysis Conf., USA: San Antonio, 2000.


% -------------------------------------------------------------------------
%% Initialization
close all
% -------------------------------------------------------------------------
% Import time history data: Processed accelereation data must be
% arranged in a columnwise format (one column for each measurement channel)
% Note that the acceleration data must be preprocessed (detrend, filtered etc.).
% Read acceleration data from the excel file
if(input_type==0)
    Acc=xlsread(Input);
else
    Acc=Input;
end
display('FDD is in progress, please wait ...')
% -------------------------------------------------------------------------
%% Compute Power Spectral Density (PSD) matrix.
% CPSD function, with default settings, is used to compute the cross power
% spectral density matrix. More sophisticated methods can also be
% applied for more accuracy.
for I=1:size(Acc,2)
    for J=1:size(Acc,2)
        [PSD(I,J,:),F(I,J,:)]=cpsd(Acc(:,I),Acc(:,J),[],[],2^(nextpow2(numel(Acc(:,1))/8)),Fs);
    end
end
Frq =squeeze(F(1,1,:));
cmif=[Frq,zeros(size(F,3))];

%% Compute Singular Values

for I=1:size(PSD,3)
    for J=1:size(Acc,2)
        cmif(I,2)=cmif(I,2)+PSD(J,J,I);
    end
end
svd=cmif(:,2);
phi =0;

figure('name','CMIF_FDD')
hold on
plot(Frq,mag2db(svd(:,1)))
xlabel('Frequency (Hz)')
ylabel('Singular values of the PSD matrix (db)')

%% -------------------------------------------------------------------------
% Inverse FFT of function
filtered_signal=ifft(svd,size(Input,1));

figure('name','ifft_FDD')
hold on
plot(real(filtered_signal))
xlabel('Filtered signal')

end

