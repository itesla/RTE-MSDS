% Copyright (c) 2018, Skrolan Endrass
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.

%% Validation of modal analysis
% This code tests the prony method, FFDD method and FDD method
% Folder paths need to be changed in the code
clear all;
close all;

%% Import data from a file
[input_data,b,c]=xlsread('/DATA/itesla/oscillations_interzones/valeur_simu.xlsx'); 

clear b;
clear c;

%% Parameters of the analysis 
visu_flag=1;                                % Visualize input data
sample_period = 0.02;                       % Enter sampling period
sampling_frequency=1/sample_period;         % Sampling frequency
time_vector=(0:sample_period:290)';         % Construction of the time vector
%time_vector=input_data(:,1);               % Get time vector from the input file

data_begin=0;                               % Chose data begin
data_end=1800;                              % Chose data end
shift_flag =1;
half_band_width=0.2;                        % Parameter for slepian functions construction in FFDD

% Extraction of the data time window of interest
signal = input_data(data_begin:end,2:end);
time_vector=time_vector(data_begin:end,1);


tsimu=[0,max(time_vector)];
prony_order=24;                             % Prony order for post-FFDD and FDD analysis

frequencies=zeros(prony_order/2,4);
damping_ratios=zeros(prony_order/2,4);

%% Pre-process of the signal
signal=signal-mean(signal);


%%
%Visualisation
if(visu_flag)
    figure('name','input_signal')
    hold on
    plot(time_vector,signal)
    xlabel('signal')
end

%%
%Test PRONY
%pronyiesla(time_vector,
%signal,model_order,vector_start_time,vector_stop_time,
%sample_period,starting_time_simu,ending_time_simu,plot_flag)

model_order=100;
cd Prony
tic
[lambda, residues]=pronyiTesla(time_vector,signal,model_order,min(time_vector)*ones(1,size(signal,2)),max(time_vector)*ones(1,size(signal,2)),sample_period,shift_flag,tsimu(1),tsimu(2),visu_flag);
toc
cd ..

% Append the results into results.mat
prony_frequencies=residues.fmodes(1:2:end);
prony_damping_ratios = residues.damp_ratios(1:2:end);

%Re-ordering of the modes
[prony_worse_damp,Dampsort]=sort(prony_damping_ratios);
prony_worse_damp = prony_worse_damp(1:4);
prony_worse_freq = prony_frequencies(Dampsort);
prony_worse_freq=prony_worse_freq(1:4);

frequencies(1:4,1)=prony_worse_freq;
damping_ratios(1:4,1)=prony_worse_damp;

save('results.mat','prony_worse_freq','prony_worse_damp')

%%
%Test FFDD
cd FDD

tic
[ffdd_Frq,ffdd_phi,filtered_signal_ffdd,singular_values]=ffdd([time_vector,signal],sampling_frequency,1,half_band_width);
toc

%Parameters for the prony method afterwards
filtered_signal_ffdd=real(filtered_signal_ffdd);
ffdd_time_vec = sample_period*[0:size(filtered_signal_ffdd,1)-1]';
vec_start_ffdd=ffdd_time_vec(1)*ones(size(filtered_signal_ffdd,2));
vec_stop_ffdd=sample_period*(size(filtered_signal_ffdd,1)-1)*ones(size(filtered_signal_ffdd,2));

cd ../Prony
tic
[lambda_ffdd, residues_ffdd]=pronyiTesla(ffdd_time_vec,filtered_signal_ffdd,prony_order,vec_start_ffdd,vec_stop_ffdd,sample_period,shift_flag,tsimu(1),tsimu(2),visu_flag);
toc
cd ..

clear vec_start_ffdd;
clear vec_stop_ffdd;

% Append results into results.mat
ffdd_frequencies = residues_ffdd.fmodes(1:2:end);
ffdd_damping_ratios = residues_ffdd.damp_ratios(1:2:end);

frequencies(1:prony_order/2,2)=ffdd_frequencies;
damping_ratios(1:prony_order/2,2)=ffdd_damping_ratios;

save('results.mat','ffdd_frequencies','ffdd_damping_ratios','-append')

%%
%Test FDD
cd FDD
tic
[fdd_Frq,fdd_phi,filtered_signal_fdd]=modified_FDD(signal,sampling_frequency,1);
toc

%Parameters for the prony method afterwards
filtered_signal_fdd=real(filtered_signal_fdd);
fdd_time_vec=sample_period*[0:size(filtered_signal_fdd,1)-1]';
vec_start_fdd=fdd_time_vec(1)*ones(size(filtered_signal_fdd,2));
vec_stop_fdd=sample_period*(size(filtered_signal_fdd,1)-1)*ones(size(filtered_signal_fdd,2));

cd ../Prony
tic
[lambda_fdd, residues_fdd]=pronyiTesla(fdd_time_vec,filtered_signal_fdd,prony_order,vec_start_fdd,vec_stop_fdd,sample_period,shift_flag,tsimu(1),tsimu(2),visu_flag);
toc
cd ..
clear vec_start_fdd;
clear vec_stop_fdd;

% Append the results into results.mat
fdd_frequencies = residues_fdd.fmodes(1:2:end);
fdd_damping_ratios = residues_fdd.damp_ratios(1:2:end);

frequencies(1:prony_order/2,3)=fdd_frequencies;
damping_ratios(1:prony_order/2,3)=fdd_damping_ratios;

save('results.mat','fdd_frequencies','fdd_damping_ratios','-append')


