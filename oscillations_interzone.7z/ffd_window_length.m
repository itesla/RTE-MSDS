% Copyright (c) 2018, Skrolan Endrass
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.

%%
%Creation of data vectors and parameters
clear all;
close all;

visu_flag=1;

[a,b,c]=xlsread('/DATA/itesla/oscillations_interzones/voltage_several.xlsx');
clear b;
clear c;

shift_flag =1;
halfband_width=0.2;
taille_fenetre=600;
prony_order=16;

%Découpage du signal en périodes de taille_fenetre secondes
nombre_fenetres_data=ceil(size(a,1)/600);

total_mean_signal=zeros(size(a,1),1);
total_time_vector=a(:,1);

%Vecteurs fréquences et taux d'amortissement
frequencies_vector=zeros(prony_order/2,nombre_fenetres_data);
damping_ratio_vector=zeros(prony_order/2,nombre_fenetres_data);

%% Execute the code on the data windows

for i=1:nombre_fenetres_data-1
    data_begin=1+(i-1)*taille_fenetre;
    if (i<nombre_fenetres_data-1)
        data_end=taille_fenetre*i;
    else
        data_end=size(a,1);
    end

    signal = a(data_begin:data_end,2:end);
    time_vector=a(data_begin:data_end,1);

    sample_period=time_vector(2)-time_vector(1);
    sampling_frequency=1/sample_period;
    time_vector=sample_period*[0:1:size(time_vector)-1]';
    tsimu=[0,max(time_vector)];
  
    %%
    %Pre-processing of the signal
    signal=signal-mean(signal);

    %%
    %Test FFDD
    cd FDD
    tic
    [ffdd_Frq,ffdd_phi,filtered_signal_ffdd,singular_values]=ffdd([time_vector,signal],sampling_frequency,1,halfband_width);

    if(i==3)
        keep_svd=singular_values;
        keep_freq=ffdd_Frq;
    end
    
    filtered_signal_ffdd=real(filtered_signal_ffdd);
    ffdd_time_vec = sample_period*[0:size(filtered_signal_ffdd,1)-1]';
    vec_start_ffdd=ffdd_time_vec(1)*ones(size(filtered_signal_ffdd,2));
    vec_stop_ffdd=sample_period*(size(filtered_signal_ffdd,1)-1)*ones(size(filtered_signal_ffdd,2));

    cd ../Prony
    [lambda_ffdd, residues_ffdd]=pronyiTesla(ffdd_time_vec,filtered_signal_ffdd,prony_order,vec_start_ffdd,vec_stop_ffdd,sample_period,shift_flag,tsimu(1),tsimu(2),visu_flag);
    cd ..
    toc
    clear vec_start_ffdd;
    clear vec_stop_ffdd;

    
    [damping_ratio_vector(:,i),Dampsort]=sort(residues_ffdd.damp_ratios(1:2:end));
    freq_vec = residues_ffdd.fmodes(1:2:end);
    frequencies_vector(:,i)=freq_vec(Dampsort);

    %frequencies_vector(:,i) = residues_ffdd.fmodes(1:2:end);
    %damping_ratio_vector(:,i) = residues_ffdd.damp_ratios(1:2:end);
end

%%
save('ffdd_results.mat','frequencies_vector','damping_ratio_vector')

 