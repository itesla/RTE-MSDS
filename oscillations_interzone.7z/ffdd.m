function [Frq,phi,filtered_signal,singular_values]=ffdd(Input,Fs,input_type,half_band)

% Copyright (c) 2018, Skrolan Endrass
% This Source Code Form is subject to the terms of the Mozilla Public
% License, v. 2.0. If a copy of the MPL was not distributed with this
% file, You can obtain one at http://mozilla.org/MPL/2.0/.

% Fast Frequency Domain Decomposition (FDD) algorithm for modal analysis
% Inputs :
%   - Input: the name of input file that contains time history data or the matrix containing the data, the first
%     column is for the time_vector
%   - Fs: sampling frequency
%   - input_type : chose 0 if the input is a file, 1 if it a matrix
%   - half_band : used for the construction of slepian sequences
% Outputs :
%   - Frq: identified frequencies
%   - phi: identified mode shapes
%   - filtered_signal : time-domain signal from the CMIF
%   - singular_values : identified singular values
% Example 1 : [Frq,phi,filtered_signal,singular_values]=FDD('Accelerations.xlsx',500,0,2);
% Example 2 : [Frq,phi,filtered_signal,singular_values]=FDD(signal_matrix,500,1,2);

% -------------------------------------------------------------------------
% Import data: Data must be arranged in a columnwise format (one column for each measurement channel)
% Fist column is the time vector

if(input_type==0)
    Acc=xlsread(Input);
else
    Acc=Input;
end
seq_length=size(Acc,1);
signal_matrix = Acc(:,2:end);

% -------------------------------------------------------------------------
% Compute Discrete prolate spheroidal (Slepian) sequences with dpss function 
dps_seq = dpss(seq_length,half_band);

% -------------------------------------------------------------------------
% Windowed FFT
nbr_windows = size(dps_seq,2);
list_of_tapered_signals = cell(1,nbr_windows);
for list_index=1:nbr_windows
    list_element= bsxfun(@times,signal_matrix,dps_seq(:,list_index));
    list_of_tapered_signals{1,list_index} = fft(list_element); 
end

% -------------------------------------------------------------------------
% Auto-spectrum estimations
list_of_auto_spectrum_estimations =cell(1,nbr_windows);
for list_index=1:nbr_windows
    list_of_auto_spectrum_estimations{1,list_index} = list_of_tapered_signals{1,list_index}.*conj(list_of_tapered_signals{1,list_index});
end

% -------------------------------------------------------------------------
% Creation of CMIF function
% Selection of the singular values between 0 and 1 Hz
interm_trace=zeros(seq_length,1);
for through_windows=1:nbr_windows
    interm_trace = interm_trace + sum(list_of_auto_spectrum_estimations{1,through_windows},2);
end
Frq = transpose(Fs*(0:(seq_length-1)/2)/seq_length);
cmif=[Frq,(1/nbr_windows)*interm_trace(1:size(Frq))];

indice_valeur_1hz=ceil(seq_length/Fs);
[bla,index_mode_max]=max(cmif(:,2));

phi=zeros(size(signal_matrix));
for through_windows=1:nbr_windows
    phi = phi + list_of_tapered_signals{1,list_index};
end
phi=1/nbr_windows*phi;

% -------------------------------------------------------------------------
% Plot of CMIF function
figure('name','CMIF_FFDD')
hold on
plot(cmif(:,1),mag2db(cmif(:,2)))
xlabel('Frequency (Hz)')
ylabel('Singular values of the PSD matrix (db)')

Frequency=cmif(:,1);
singular_values=cmif(:,2);

% -------------------------------------------------------------------------
% Inverse FFT of function
filtered_signal=ifft(cmif(1:indice_valeur_1hz,2),seq_length);
% figure('name','ifft_FFDD')
% hold on
% plot(real(filtered_signal))
% xlabel('Filtered signal')
end

