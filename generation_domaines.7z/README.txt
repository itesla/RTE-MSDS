#Description

Permet de calculer un domaine stable d'initialisation pour un g�n�rateur dont on a les mod�les de r�gulations
Fichiers n�cessaires
	- .dta
	- regulations
	- .csv, with the groups to generate
	- optional : indicate in a file which generators should be constrained to positive P domains
	

##Pr�-requis

- Python
- Logiciel de simulation Eurostag
Les diff�rents fichiers pour faire tourner la g�n�ration de domaines :
	Batch file : 
	- MachineDomain
	Python files :
	- CreatedtaFile.py
	- CreateMachineDomain.py
	- CreatePlaneDomain.py
	- IndusMachineDomain.py
	- MachinStableDomainSearch.py
	- ProjectionDomain.py

###Installation

??


####D�tails sur les diff�rents fichiers python
******************
MachineDomain.bat
******************
Allows to indicate the paths to the different files :
	- RefdtaFile 			 : to .dta file (and path to dictionnary)
	- generatorsFile 		 : to .csv file containing generators name 
	- regulPath				 : to regulations  
	- negativeGeneratorsFile : to .txt file containing the generators where domain should be constrained to P >0 with outputPath
Two parametres :
	- visualisation			 : chose or not to have a 3D visualisation of domains at end of computation
	- nbr_points			 : chose number of points to use for creation of domains

Launches IndusMachineDomain.py

******************
IndusMachineDomain.py
******************
Creates a file for each generator containing regulations, dta and seq.
Runs MachineStableDomainSearch.py in parallel (number of cores used can be chosen).
At the end of the computations, agregates the different domains into a ampl_domains.txt file

******************
MachineStableDomainSearch.py 
******************
Computes 3D stable domain of generator, details of the different functions used are given in the comments of those functions in the python file.
This is where eurostag is called, so need to specify path to installation in commands used (after if systemCallMode)
