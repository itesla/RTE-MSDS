# -*- coding: utf-8 -*-
#===========================#
# created on april 2018
#===========================#
# Copyright (c) 2018, Skrolan Endrass
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# Should be executed in folder containing the folder of all the generated domains
# Gets for each generator folder :
# 	- Init stable, unstable and unknown in
#	- Final stable out, unstable in, unknown in, stable in 
#	- Nominal point stable or not 
#	- Nominal point in or not 

import os
from scipy import interpolate
import numpy as np
import argparse

def FreadFiles(FilePath, generator):
	data_vector = np.zeros(shape=(0,1))
	stable_nom_point = True
	nom_point_in = True

	with open(FilePath,'r') as File:
		lines = File.readlines()
	for line in lines:
		if((line.find("Business Warning: Nominal point is not stable: ",0,47)!=-1)):
			stable_nom_point = False
		if((line.find("Initially inside stable points",0,30)!=-1)):
			data_vector = np.vstack((data_vector,line[40:-1]))
		if((line.find("Initially inside unstable points",0,32)!=-1)):
			data_vector = np.vstack((data_vector,line[40:-1]))
		if((line.find("Initially inside unknown points",0,31)!=-1)):
			data_vector = np.vstack((data_vector,line[40:-1]))
		if((line.find("Finally outside stable points",0,29)!=-1)):
			data_vector = np.vstack((data_vector,line[40:-1]))
		if((line.find("Finally inside unstable points",0,30)!=-1)):
			data_vector = np.vstack((data_vector,line[40:-1]))
		if((line.find("Finally inside unknown points",0,29)!=-1)):
			data_vector = np.vstack((data_vector,line[40:-1]))
		if((line.find("Finally inside stable points",0,28)!=-1)):
			data_vector = np.vstack((data_vector,line[40:-1]))
		if((line.find("The nominal point would be excluded by the reduction with a margin of",0,69)!=-1)):
			nom_point_in = False
	if(stable_nom_point):
		data_vector = np.vstack((data_vector,str("Ok")))
	else:
		data_vector = np.vstack((data_vector,str("NOk")))
	if(nom_point_in):
		data_vector = np.vstack((data_vector,str("Ok")))
	else:
		data_vector = np.vstack((data_vector,str("NOk")))
	File.close()
	return data_vector


def FreadGenerators(GeneratorsPath):
	generators = np.zeros(shape=(0,2))

	with open(GeneratorsPath,'r') as GeneratorsFile:
		lines = GeneratorsFile.readlines()

	for line in lines:
		generators = np.vstack((generators,line.rstrip().split(';')))
	GeneratorsFile.close()
	return generators


def FwriteFile(outputPath, info_vec, generator):
	thefile = open(outputPath,'a')
	thefile.write(generator[0])
	thefile.write(";")
	thefile.write(info_vec[0,0])
	thefile.write(str(";"))
	thefile.write(str(info_vec[1,0]))
	thefile.write(str(";"))
	thefile.write(str(info_vec[2,0]))
	thefile.write(str(";"))
	thefile.write(str(info_vec[3,0]))
	thefile.write(str(";"))
	thefile.write(str(info_vec[4,0]))
	thefile.write(str(";"))
	thefile.write(str(info_vec[5,0]))
	thefile.write(str(";"))
	thefile.write(str(info_vec[6,0]))
	thefile.write(str(";"))
	thefile.write(str(info_vec[7,0]))
	thefile.write(str(";"))
	thefile.write(str(info_vec[8,0]))
	thefile.write(str("\n"))
	thefile.close()
	
if __name__ == '__main__':
	generatorFilePath	= os.path.join("gen_get_time.txt")
	outputPath			= os.path.join("domain_info_40000pts.txt")
	thefil = open(outputPath,'w')
	thefil.write("Generator;Init stable in; Init unstable in; Init unknown in; Final stable out; Final unstable in; Final unknown in; Final stable in; Nominal point stable; Nominal point in")
	thefil.write("\n")
	thefil.close()
	#Vector creation
	generators 	= FreadGenerators(generatorFilePath)

	for generator in generators :
		os.chdir(os.path.join(".",generator[0]))
		temp_file = os.path.join("output.txt")

		if(os.path.isfile(temp_file)):
			info_vec = FreadFiles(temp_file, generator)
		os.chdir("../")
		if(len(info_vec)>2):
			FwriteFile(outputPath, info_vec, generator)
		