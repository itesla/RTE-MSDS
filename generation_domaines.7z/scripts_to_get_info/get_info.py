# -*- coding: utf-8 -*-
#===========================#
# created on april 2018
#===========================#
# Copyright (c) 2018, Skrolan Endrass
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# Should be executed in folder containing the folder of all the generated domains
# Gets for each generator folder :
# 	- the number of directions explored
#	- the number of corners
#	- the number of lost points

import os
from scipy import interpolate
import numpy as np
import argparse

def FreadFiles(FilePath, generator):
	data_vector = np.zeros(shape=(0,1))
	with open(FilePath,'r') as File:
		lines = File.readlines()

	for line in lines:
		if((line.find("Number of directions:  ",0, 23)!=-1)):
			first_info = line.find(" , number of corner points:  ")
			data_vector = np.vstack((data_vector,line[23:first_info]))
			second_info = line.find("  Points lost due to non-convexity:  ")
			data_vector = np.vstack((data_vector,line[first_info+29:second_info]))
			data_vector = np.vstack((data_vector,line[second_info+37:-1]))	
	File.close()
	return data_vector

def FreadGenerators(GeneratorsPath):
	generators = np.zeros(shape=(0,2))

	with open(GeneratorsPath,'r') as GeneratorsFile:
		lines = GeneratorsFile.readlines()

	for line in lines:
		generators = np.vstack((generators,line.rstrip().split(';')))
	GeneratorsFile.close()
	return generators


def FwriteFile(outputPath, time_vec, pts_number, generator):
	thefile = open(outputPath,'a')
	thefile.write(generator[0])
	thefile.write(str(";"))
	thefile.write(str(pts_number))
	thefile.write(str(";"))
	thefile.write(str(time_vec[0,0]))
	thefile.write(str(";"))
	thefile.write(str(time_vec[1,0]))
	thefile.write(str(";"))
	thefile.write(str(time_vec[2,0]))
	thefile.write(str("\n"))
	thefile.close()
	
if __name__ == '__main__':
	generatorFilePath	= os.path.join("gen_get_time.txt")
	outputPath			= os.path.join("info.txt")
	pts_number			= 10000 #Enter the number of points used as parameter 
	thefil = open(outputPath,'w')
	thefil.write("Generator;Points;Directions;Corners;Lost points")
	#Vector creation
	generators 	= FreadGenerators(generatorFilePath)

	for generator in generators :
		os.chdir(os.path.join(".",generator[0]))
		temp_file = os.path.join("output.txt")

		if(os.path.isfile(temp_file)):
			time_vec = FreadFiles(temp_file, generator)
		os.chdir("../")
		if(len(time_vec)>2):
			FwriteFile(outputPath, time_vec, pts_number, generator)
		