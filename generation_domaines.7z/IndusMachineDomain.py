# -*- coding: utf-8 -*-

# Copyright (c) 2016, Pierre Saikaly  (saikalypierre@gmail.com)
# Copyright (c) 2017, RTE (Author: Frederic Troalen)
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

#===========================#
# created on 06 june 2016
#===========================#

# Import Python dependencies :
# ----------------------------
import imp
import os
import sys
import numpy as np
from numpy import linalg
import math as m
from math import pi
from math import sqrt
from math import fabs
import random as rand
import time
import shutil
from operator import attrgetter
import subprocess
import multiprocessing as mp

import MachineStableDomainSearch

def FwriteFiles(MachinesdtaPath,generators, regulPath):
	""" 
		Creates a file for each machine in reference file :
		Inputs  :
			- MachinesdtaPath : location of reference file
		Outputs : 
			- n single machine dta files
			- generators_in  : generators that are in the dta
			- generators_out : generators that are not in the dta
		Used in :
			- main
	"""
	regulators = []       # list of regulators for the generator
	generators_in  = np.zeros(shape=(0,4))   # generators that are in the MachinesdtaPath
	generators_out = np.zeros(shape=(0,2))   # generators that are out of MachinesdtaPath
	print('Read dta file {}'.format(MachinesdtaPath))
	#Opening Reference file :
	#------------------------
	with open(MachinesdtaPath) as Machinefile:
		lines = Machinefile.readlines()
		#Looking for machines :
		#----------------------
		for i, line in enumerate(lines):
			if line.startswith("M2       U") or line.startswith("M2       S"):
				tmpLine = list(lines[i+1])
				tmpLine[9:17]="N1      "
				lines[i+1] = "".join(tmpLine)
				
				#Writing specific machine file :
				#--------------------------------
				MachineName = lines[i+1][0:8]
				if MachineName in generators[:,0]:
					tmp = generators[MachineName==generators[:,0],:]
					gen_in = np.append(tmp[0,:],lines[i+1].split()[3])
					gen_in = np.append(gen_in,lines[i+1].split()[4])
					generators_in = np.vstack((generators_in,gen_in))
					MachineRefName = generators[MachineName==generators[:,0],0][0]
					
					#Creating the folder of the machine if it doesn't exist :
					#--------------------------------					
					if not os.path.exists(MachineRefName):
						os.makedirs(MachineRefName)
						#copy of dll files into the directory 
						shutil.copyfile('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\mkl_avx2.dll', os.path.join(MachineRefName, 'mkl_avx2.dll'))
						shutil.copyfile('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\mkl_core.dll',os.path.join(MachineRefName, 'mkl_core.dll'))
						shutil.copy2('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\mkl_p4.dll',os.path.join(MachineRefName, 'mkl_p4.dll'))
						shutil.copy2('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\libiomp5md.dll',os.path.join(MachineRefName, 'libiomp5md.dll'))
						print "Copy of dll files successfull"
						
						time.sleep(0.1)

						filename = 'simTest' + '.dta'
						filename = os.path.join(MachineRefName, filename)
						with open(filename, 'w') as f:
							#Writing Header :
							#----------------
							f.write("HEADER     "+ time.strftime("%d/%m/%y") +" 5.1\n \n")
							#Writing Machine information :
							#-----------------------------
							f.write(lines[i])
							f.write(lines[i+1])
							f.write(lines[i+2])
							f.write(lines[i+3])
							f.write(lines[i+4])
							f.write(lines[i+5])
							i += 6
							#Writing Regulators information :
							#--------------------------------
							f.write("\n")
							while (("M2       S") not in lines[i] and ("M2       U") not in lines[i]) and i<len(lines)-1:
								if lines[i].startswith("R " + MachineName):
									f.write(lines[i])
									f.write(lines[i+1])
									regulators.append(lines[i+1].split()[0])
									f.write(" \n \n \n")
								i += 1
								time.sleep(0.01)
							#Writing Network information :
							#-----------------------------
							f.write("I1 \nN2             0.     0.02      90.     100. \n \n \nLOADP   1\n         1              1.       1. \n \n \n \n \n \n"
								"CH \n1        W\n \n \n")

						FcopyRegulators(regulators,MachineRefName, regulPath)
						FwriteSeq(MachineRefName)
						time.sleep(0.1)
						regulators = []
						print MachineName, " is done !"
					else:
						#copy of dll files into the directory 
						shutil.copyfile('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\mkl_avx2.dll', os.path.join(MachineRefName, 'mkl_avx2.dll'))
						shutil.copyfile('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\mkl_core.dll',os.path.join(MachineRefName, 'mkl_core.dll'))
						shutil.copy2('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\mkl_p4.dll',os.path.join(MachineRefName, 'mkl_p4.dll'))
						shutil.copy2('C:\Users\iTesla\Documents\PQV\IIDM_Eurostag_Database\IIDM_Eurostag_Database\DDB\DLL\libiomp5md.dll',os.path.join(MachineRefName, 'libiomp5md.dll'))
						print "Copy of dll files successfull"
						print MachineName, " already OK"
				else:
					generators_out = np.vstack((generators_out,generators[MachineName==generators[:,1],:]))

	return generators_in, generators_out

def FreadGenerators(GeneratorsPath):
	""" 
		Reads the list of machines for which to compute the domains :
		Inputs  :
			- GeneratorsPath : location of generators to process
		Outputs : 
			- Generators : array of generators with dictionary and internal name
		Used in :
			- main
	"""	
	generators = np.zeros(shape=(0,2))

	with open(GeneratorsPath,'r') as GeneratorsFile:
		lines = GeneratorsFile.readlines()

	for line in lines:
		generators = np.vstack((generators,line.rstrip().split(';')))
	
	return generators

def FcopyRegulators(regulators, MachineName, regulPath):
	""" 
		Copy the regulators specified :
		Inputs  :
			- regulators : list of regulators to copy
			- regulPath : the path to the regulators
			- MachineName : the name of the machine being handled
		Outputs : 
			- None, the regulators are copied in the corresponding folder of the machine
		Used in :
			- FwriteFiles
	"""
	for regulator in regulators:
		nbFound=0
		for basename in os.listdir(regulPath):
			if basename.lower().startswith(regulator.lower()):
				pathname = os.path.join(regulPath, basename)
				if os.path.isfile(pathname):
					try:
						shutil.copy(pathname, os.path.join(".",MachineName))
						nbFound=nbFound+1
					except EnvironmentError:
						print "Error: Impossible to copy ", pathname, " in ", MachineName
				else:
					print "Error: Impossible to copy ", pathname, " in ", MachineName, " because the file does not exist"
		if nbFound==0:
			print "Error: regulation ", regulator, " not found"
		time.sleep(0.01)

def FwriteSeq(MachineName):
	""" 
		Create the seq file for Eurostag simulation
		Inputs  :
			- MachineName
		Outputs : 
			- None, the seq file is created in the folder of the machine
		Used in :
			- FwriteFiles
	"""
	filename = os.path.join(MachineName,'simTest.seq')

	with open(filename,'w') as f:
		f.write("HEADER     "+ time.strftime("%d/%m/%y") +" 5.1\n \n")
		f.write('PARAM\n')
		f.write('         0  0  1\n')
		f.write('                 0.0001         0.0001          0.001             0.             0. 1\n')
		f.write('\n')
		f.write('TIME\n')
		f.write('               0.000001            60.             0.\n')
		f.write('\n')
		f.write('EVENTS\n')
		f.write('.0000001 STOP')
		f.write(' \n \n')

def FcallProgram(generator,non_neg_generators,visualisation,nbr_directions):
	""" 
		Calls MachineStableDomainSearch.py for the generator in input 
		Inputs  :
			- generator : list of generators for which to create the domains
			- non_neg_generators : constraint P >0 for the domain
			- visualisation : chose to vizualize the 3D domain at the end of the generation
			- nbr_directions : approximate number of points used to create domain
		Outputs : 
			- outputs of MachineStableDomainSearch.py
		Used in :
			- main
	"""

	print "Currently working on : ", generator[0]
	# Moving to file of generator :
	# -----------------------------
	os.chdir(os.path.join(".",generator[0]))
	print "Current directory : ",  os.getcwd()

	# Lauching python process :
	# -------------------------	
	if generator[0] in non_neg_generators :
		command_line = "MachineStableDomainSearch.py -v 1 -i "+visualisation+" -n -d "+nbr_directions
	else :
		command_line = "MachineStableDomainSearch.py -v 1 -i "+visualisation+" -d "+nbr_directions

	python_process = os.path.join("..",command_line)
	time_start = time.clock()

	
	if os.name == 'nt':
		with open("output.txt",'w') as f:
			commandString = "python " + python_process
			print commandString
			try:
				if os.name == 'nt':
					subprocess.call(commandString, stdout=f, stderr=subprocess.STDOUT)
				else:
					process = subprocess.Popen(commandString, shell=True, close_fds=True, stdout=f, stderr=subprocess.STDOUT)
					process.wait()
					print "MachineStableDomainSearch process return code: ", process.returncode
			except:
				print "ERROR: Impossible to launch MachineStableDomainSearch.py"
				f.write("ERROR: Impossible to launch MachineStableDomainSearch.py")
	else:
		sys.stdout = open("output.txt", "w")
		sys.stderr = open("output.err", "w")
		MachineStableDomainSearch.main(1,0)

	time_elapsed = (time.clock() - time_start)

	print generator[0], " is Done : ", time_elapsed 
	time.sleep(0.1)
	# Moving back to parent folder
	os.chdir("..")

def FappendResults(generators):
	"""
		Append the results of computed domain to a single text file
		Inputs : 
			- generators : list of input generators
		Ouputs : 
			- ampl_generators_domains.txt 
		Used in :
			- main
	"""

	generator_prob = np.zeros(shape=(0,4)) # List of generators with problems

	with open("ampl_generators_domains.txt", "w") as f: 
		f.write("# " + time.strftime("%d/%m/%y") + "\n")
		f.write("#num id P(MW) Q(MVar) V(kV) RHS(lt) " + "Vnominal(kV)" + " " + "id_internal" + "\n")

	with open("ampl_generators_domains.txt", "a") as f: 
		for generator in generators:
			file_name=str("generators_domains_MC_"+ generator[0]+".txt")
			resultfile = os.path.join(generator[0],file_name)
			try:
				with open(resultfile,'r') as f_res:
					lines = f_res.readlines()
					for line in lines:
						if '#' not in line:
							f.write(line)
			except IOError:
				generator_prob = np.vstack((generator_prob,generator))

			time.sleep(0.1)

	return generator_prob

if __name__ == '__main__':

	# Get list of worker from cpu count
	mp.freeze_support()
	PROCESSES = min(40,mp.cpu_count())
	
	print "Parallel computation on ", PROCESSES , " processes"
	print 'Number of arguments:', len(sys.argv), 'arguments.'
	print 'Argument List:', str(sys.argv)	
	
	RefdtaFile 		= sys.argv[1]
	GeneratorsFile  = sys.argv[2]  
	regulPath 		= sys.argv[3]  
	nonNegative     = sys.argv[4]
	visualisation   = sys.argv[5]
	nbr_directions  = sys.argv[6]

	RefdtaPath     = os.path.join(RefdtaFile)     # Path of dtaFile containing machine to test
	GeneratorsPath = os.path.join(GeneratorsFile) # Path of file containing generators to test
	NonNegGeneratorsPath = os.path.join(nonNegative) 	# Path of file containing generators where there is a P > 0 constraint on the domain

	generators    = FreadGenerators(GeneratorsPath)
	non_neg_generators = FreadGenerators(NonNegGeneratorsPath)
	
	# Create a folder for each machine
	generators_in, generators_out = FwriteFiles(RefdtaPath, generators, regulPath)
	np.savetxt('generators_in_info.txt', generators_in, fmt='%s')
	print "Files have all been written \n"

	# Launch the domain creation in parallel on PROCESSES number of cores
	pool = mp.Pool(processes=PROCESSES)
	for generator in generators_in:
		pool.apply_async(FcallProgram, args=(generator,non_neg_generators,visualisation,nbr_directions,))
		time.sleep(0.1)
	pool.close()
	pool.join()

	# waiting for processes to close
	time.sleep(1)
	
	print "Fin du calcul - Concatenation des resultats"
	generators_prob = FappendResults(generators_in)

	print "Liste des generateurs ayant eu un prb : \n" , generators_prob
	np.savetxt('generators_pb.txt',generators_prob, fmt='%s', delimiter=';')
	print "Liste des generateurs non inclus dans le .dta : \n" , generators_out
	np.savetxt('generators_out.txt',generators_out, fmt='%s', delimiter=';')


	