# -*- coding: utf-8 -*-

# Copyright (c) 2016, Pierre Saikaly  (saikalypierre@gmail.com)
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

#===========================#
# created on 14 april 2016
#===========================#

# Import Python dependencies :
# ----------------------------
import imp
import os
import sys
import numpy as np
from numpy import linalg
import math as m
from math import pi
from math import sqrt
from math import fabs
import random as rand
import time
from operator import attrgetter
import scipy.optimize
from scipy.spatial import ConvexHull
import argparse
import subprocess
import pickle

# Import Python visualisation libraries :
# ---------------------------------------
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from mpl_toolkits.mplot3d import Axes3D
from itertools import product, combinations
from matplotlib.patches import FancyArrowPatch
from mpl_toolkits.mplot3d import proj3d
from matplotlib.path import Path

# Import custom dependencies :
# -----------------------------
import CreateMachineDomain

# Import Eurostag DLL :
# ---------------------
eurostag_path = os.environ.get('EUROSTAG')
if (eurostag_path is None):
	eurostag_path = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Eurostag"))
time_start = time.time()
try:
	eurostag_python_path = os.path.join(eurostag_path, 'python_interface', 'eurostag.py')
	l = imp.load_source ('eurostag', eurostag_python_path)
	print "Eurostag has been succesfully loaded\n"
except Exception as exc:
	print("Failed to load Eurostag API :" + str(exc))
	print eurostag_python_path
	sys.exit(1)
time_now = time.time()
time_elapsed = (time.time() - time_start)
print "[Elapsed time] API loading time", time_elapsed


# Defining vector visualisation class :
# -------------------------------------
class Arrow3D(FancyArrowPatch):
    def __init__(self, xs, ys, zs, *args, **kwargs):
        FancyArrowPatch.__init__(self, (0,0), (0,0), *args, **kwargs)
        self._verts3d = xs, ys, zs

    def draw(self, renderer):
        xs3d, ys3d, zs3d = self._verts3d
        xs, ys, zs = proj3d.proj_transform(xs3d, ys3d, zs3d, renderer.M)
        self.set_positions((xs[0],ys[0]),(xs[1],ys[1]))
        FancyArrowPatch.draw(self, renderer)

# Data class :
# ------------
class PointBoundary():
	"""Define point of boundary in pu and si with its normal"""

	def __init__(self,p_input,n_input,unit,P_boundaries,Q_boundaries,U_boundaries):
		"""
			Define point and normal in both pu and si :
				Inputs :
					p_input : P,Q,U point
					n_input : P,Q,U vector
					unit    : si or pu
				Output :
					point_si : P,Q,U in si
					point_pu : P,Q,U in pu
					normal_si : P,Q,U in si
					normal_si : P,Q,U in pu
		"""
		if unit=="pu":
			self.point_pu = p_input
			self.normal_pu = n_input
			self.point_si = Conversion_pu_si(self.point_pu,P_boundaries,Q_boundaries,U_boundaries)
			self.normal_si = Conversion_pu_si(self.normal_pu,P_boundaries,Q_boundaries,U_boundaries)
		elif unit=="si":
			self.point_si = p_input
			self.normal_si = n_input
			self.point_pu = Conversion_si_pu(self.point_si,P_boundaries,Q_boundaries,U_boundaries)
			self.normal_pu = Conversion_si_pu(self.normal_si,P_boundaries,Q_boundaries,U_boundaries)
		else:
			print "Specifier l'unite : pu ou si"

class PointDomain():
	"""Define point of domain in pu and si"""

	def __init__(self,p_input,unit,P_boundaries,Q_boundaries,U_boundaries):
		"""
			Define point in both pu and si :
				Inputs :
					p_input : P,Q,U point
					unit    : si or pu
				Output :
					point_si : P,Q,U in si
					point_pu : P,Q,U in pu
		"""
		if unit=="pu":
			self.point_pu = p_input
			self.point_si = Conversion_pu_si(self.point_pu,P_boundaries,Q_boundaries,U_boundaries)
		elif unit=="si":
			self.point_si = p_input
			self.point_pu = Conversion_si_pu(self.point_si,P_boundaries,Q_boundaries,U_boundaries)
		else:
			print "Specifier l'unite : pu ou si"

def Conversion_pu_si(data_pu,P_boundaries,Q_boundaries,U_boundaries):
	"""
		Converts data from pu to si :
		Inputs :
			- data_pu : P,Q,U data in pu
			- Study boundaries : P_boundaries, Q_boundaries, U_boundaries
		Output :
			- data_si : Converted point in si
		Used in :
			- Main and classes
	"""
	# Creating output :
	# -----------------
	data_si = np.zeros(3)
	# Converting :
	# ------------
	data_si[0] = (data_pu[0]) * (P_boundaries[1] - P_boundaries[0]) + P_boundaries[0]
	data_si[1] = (data_pu[1]) * (Q_boundaries[1] - Q_boundaries[0]) + Q_boundaries[0]
	data_si[2] = (data_pu[2]) * (U_boundaries[1] - U_boundaries[0]) + U_boundaries[0]

	return data_si

def Conversion_si_pu(data_si,P_boundaries,Q_boundaries,U_boundaries):
	"""
		Converts data from pu to si :
		Inputs :
			- data_si : P,Q,U data in si
			- Study boundaries : P_boundaries, Q_boundaries, U_boundaries
		Output :
			- data_pu : Converted point in pu
		Used in :
			- Main and classes
	"""	
	# Creating output :
	# -----------------
	data_pu = np.zeros(3)
	# Converting :
	# ------------
	data_pu[0] = ((data_si[0] - P_boundaries[0]) / (P_boundaries[1] - P_boundaries[0])) 
	data_pu[1] = ((data_si[1] - Q_boundaries[0]) / (Q_boundaries[1] - Q_boundaries[0])) 
	data_pu[2] = ((data_si[2] - U_boundaries[0]) / (U_boundaries[1] - U_boundaries[0])) 

	return data_pu


# Program functions :
# -------------------		
def Fgroup(X, seqPath, dtaPath, echPath, P_boundaries, Q_boundaries, U_boundaries, U_nominal, P_nominal, precision, equi_value_OK, equi_value_NOK):
	""" Calls Eurostag simulator and simulates
		Inputs :
			- X       : machine parameters [P,Q,U]
			- seqPath : Machine .seq file 
			- dtaPath : Machine .dta file
			- echPath : Machine .ech file
			- Study boundaries
			- precision
			- equi_value : values for which to consider stable or unstable
		Output : 
			- alpha : Eurostag status
			- X1    : Eurostag stable point
			- equi_value_used 
		Used in :
			- Fexploration
			- FmonteCarlo
			- Main
	"""

	print "Fgroup called"
	if os.name == 'nt':
		systemCallMode=False
	else :
		systemCallMode=True
		print "System call mode because of python API bug"
	
	# Local Variables : 
	# -----------------
	X1     = np.zeros(shape=3) # The simulation results are stored here
	E      = np.zeros(shape=3) # normalisation 
	t2     = 0.5 # Accepted biais
	alpha  = 0 # Initial indicator
	status = 5 # Eurostag status

	etat   = "ETAT D'EQUILIBRE A  0.10000D-02 VERIFIE POUR LES EQUATIONS MACHINE"
	etat2  = "ETAT D'EQUILIBRE A  0.10000D-02 NON VERIFIE DANS LES EQUATIONS SUIVANTES"

	erreur0227 = "ERR-0227.0512"
	
	setUpFailure = False

	if systemCallMode:
		time_start = time.time()
		rc1=os.system('export EUROSTAG=/usr/local/eurostag/v52_rte; /usr/local/bin/eustag_cpt_noGUI_rte -lf simTest.ech')
		time_elapsed = (time.time() - time_start)
		print "[Elapsed time] Eurostag lf call duration:", time_elapsed 
		print "Eurostag lf process return code: ", rc1
		if rc1 == 0 :
			time_start_time = time.time()
			rc2=os.system('export EUROSTAG=/usr/local/eurostag/v52_rte; ulimit -s unlimited; /usr/local/bin/eustag_cpt_noGUI_rte -s simTest.seq simTest.dta simTest.sav')
			time_elapsed_time = (time.time() - time_start_time)
			print "[Elapsed time] Eurostag s call duration:",  time_elapsed_time
			if rc2 !=0 :
				setUpFailure=True
		else:
			setUpFailure=True
	else:
		# Setting up simulation :
		# -----------------------
		
		l.setVerboseMode(1)
		try:
			l.initLF(echPath)
		except:
			print "Eurostag init LF failure on ", X
			setUpFailure=True
			
		if not(setUpFailure):
			try:
				l.runLF()
				print 'Load Flow successfull !'
			except:
				print "Eurostag load-flow failure", X
				setUpFailure=True
				
		if not(setUpFailure):
			savPath = os.path.join("simTest.sav")
			try:
				l.initDynSimu(seqPath, dtaPath, savPath)
				print 'Dynamic simulation initialised'
			except :
				print "=>Eurostag initialisation failure", X
				setUpFailure=True
	
	time_start = time.time()
	if setUpFailure==True:
		alpha=2
		equi_value_used=float('inf')
		X0=X
		X1=X
		detailed_status_A = "Initialization failure"
		detailed_status_B = detailed_status_A
	else:
		if not(systemCallMode):
			MachineName = l.getMachines()
			Nodes = l.getNodes()
			print "Machine :", MachineName, "\n"
			X1[2], angle = l.getNodeVoltage('N1      ', 'P')
			Unom, angle  = l.getNodeVoltage('N2      ', 'P')
			X1[0:2]      = l.getMachinePower(MachineName[0])
			X0=X1
			print "P,Q,U INITIALEMENT :", X1
		else :
			X0=X

		# Checking Eurostag status :
		# --------------------------
		detailed_status_A = ""
		#Deactivated to get full control and full output (including equi_value_used)
		if False and (etat in open("simTest.out").read()):
			# Eurostag returns stable
			status = 0
			l.simulate()
			detailed_status_A = "Eurostag Stable"
			equi_value_used=float('inf')
		else:
			# Eurostag returns unstable :
			# ---------------------------
			equi_value = np.empty(0)
			nbTrial=10
			while equi_value.shape[0]==0 and nbTrial>0:
				with open("simTest.out") as outfile:
					lines = outfile.readlines()
					for i, line in enumerate(lines):
						if etat2 in line:
							k = i+5
							if len(lines)<k-1 :
								print "ERROR : simTest.out does not seem to be complete. Default value for unstable written"
								print lines
								equi_value = np.hstack((equi_value,float('inf')))
							else :
								while (lines[k]!="\n"):
									value_line = lines[k].split(None)[-2]
									value_real = float(value_line.split("D")[0])*10**int(value_line.split("D")[1])
									print "Line with equilibrium value (>0.02) '", lines[k], "'"
									print "'", value_line, "'"
									equi_value = np.hstack((equi_value,abs(value_real)))
									k += 1
						elif etat in line:
							k = i+1
							if len(lines)<k-1 :
								print "ERROR : simTest.out does not seem to be complete. Default value for stable written"
								value_real = 0.02
							else:
								tmp_line = lines[k]
								if os.name == 'nt':
									value_line = tmp_line[59:70]
								else:
									value_line = tmp_line[60:71]
								print "Line with equilibrium value (<0.02) '", tmp_line, "'"
								print "'", value_line, "'"
								value_real = float(value_line.split("D")[0])*10**int(value_line.split("D")[1])
							equi_value = np.hstack((equi_value,value_real))
						elif erreur0227 in line :
							if not(systemCallMode):
								print "Error: it should have been seen before that initialization is impossible because it results in out of bound values"
							else:
								print "Initialization is impossible because it results in out of bound values"
							equi_value = np.hstack((equi_value,float('inf')))
					outfile.close()
				if equi_value.shape[0]==0:
					print "Warning: simTest.out access issue"
					time.sleep(0.1)
					nbTrial=nbTrial-1

			# Checking tolerance :
			# --------------------
			if equi_value.shape[0]==0:
				#if not(systemCallMode):
				print "ERROR: No equation value found in Eurostag log"
				for i, line in enumerate(lines):
					print line
				#else:
				equi_value = np.hstack((equi_value,float('inf')))
					
			equi_value_used = np.amax(abs(equi_value))
			print "Used equilibrium value: ", equi_value_used, "\n"
			if (equi_value_used < equi_value_OK):
				status = 0
				if not(systemCallMode):
					l.simulate()
				detailed_status_A = "Prog Stable"
			elif (equi_value_used > equi_value_NOK): 
				print "Unstable case. Dynamic simulation stopped."
				status = 2
				if not(systemCallMode):
					l.stopDynSimu()
				detailed_status_A = "Prog Unstable"
			elif (equi_value_OK <= equi_value_used and equi_value_used <= equi_value_NOK):
				print "Unknown case. Dynamic simulation performed."
				status = 1
				if not(systemCallMode):
					l.simulate()
				detailed_status_A = "Prog Unknown"
			else:
				print "ERROR: Default case for numerical errors (should not happen). Considered as an Unstable case but dynamic simulation performed"
				status = 2
				if not(systemCallMode):
					l.simulate()
				detailed_status_A = "Prog Error"
			# time.sleep(1)

		if not(systemCallMode):
			X1[2], angle = l.getNodeVoltage('N1      ', 'P')
			X1[0:2]      = l.getMachinePower(MachineName[0])
		
			sys.stderr.flush()
			sys.stdout.flush()
			
			print "P,Q,U FINALEMENT   :", X1	

		print ".... Eurostag status : ", status, " (0:stable; 1:Unknown; 2:unstable)....\n"

		print "#=====================================#"
		print "#    Fin de la simulation Eurostag    #"
		print "#=====================================#\n"
		# time.sleep(0.01)
		# Normalisation :
		# ---------------
		X_pu  =	Conversion_si_pu(X,P_boundaries,Q_boundaries,U_boundaries)
		X1_pu = Conversion_si_pu(X1,P_boundaries,Q_boundaries,U_boundaries)
		E = X_pu - X1_pu

		# Returning eurostag status :
		# ---------------------------
		print X_pu, X1_pu
		print X, X1
		print "Start to end position distance:", np.linalg.norm(E)
		print "Precision                     :", precision
		detailed_status_B="";
		# time.sleep(1)
		if not(systemCallMode):
			if (np.linalg.norm(E)<precision*1000):
				if (status == 0):
					alpha = 0
					detailed_status_B="Stable";
				elif (status == 2):
					alpha = 2
					detailed_status_B="Unstable";
				elif (status == 1):
					alpha = 1
					detailed_status_B="Unknown";
			else:
				print "Unstable status decided by simulation end point"
				detailed_status_B="Unknown by end point";
				alpha = 1
		else :
			alpha=status
			detailed_status_B=detailed_status_A
	
	print "[OL AA][Eurostag call],", X0[0], ",", X0[1], ",", X0[2], ",", X1[0], ",", X1[1], ",", X1[2], ",", alpha, ",", detailed_status_A, ",", detailed_status_B, "," , equi_value_used,"\n"
	print "[Elapsed time] Time in remaining of fgroup:", (time.time()-time_start)
	
	return alpha, X1, equi_value_used

def Fexploration(O,B,Esp,seqPath, dtaPath, echPath, U_nominal, P_nominal, P_boundaries, Q_boundaries, U_boundaries, MachineName, equi_value_OK, equi_value_NOK):
	""" 
		Computes last stable point in a direction with dichotomy :
		Inputs : 
			- O   : Stable origin
			- B   : Boundary point in direction
			- Esp : Boundary precision
			- Study boundaries
			- Machine nominal power and tension
		Output :
			- A   : Last Stable point 
			- tested points and their status
		Used in :
			- FplanTangent
			- FmonteCarlo
			- Main
	"""
	
	# Initialisation des variables internes :
	# ---------------------------------------
	C = np.zeros(3)          # point in unstable part
	A = np.zeros(3)          # point in stable part
	T = np.zeros(3)          # test point
	X = np.zeros(3)          # eurostag point result
	d = 0                    # distance between stable and unstable point
	# Initialisation :
	# ----------------
	A = O
	C = B
	T = C
	# distance has to be computed in pu !
	A_pu = Conversion_si_pu(A,P_boundaries,Q_boundaries,U_boundaries)
	C_pu = Conversion_si_pu(C,P_boundaries,Q_boundaries,U_boundaries)
	d = np.linalg.norm(A_pu-C_pu)

	if d<Esp:
		print "ERROR: Dichotomy called on an empty segment : ", O, " ", B
	else:
		print "Dichotomy from ", O, "to", B
	
	testedPoints		= np.zeros(shape=(0,3)) 	# Store tested points
	testedPointsStatus	= np.zeros(shape=(0,2)) 	# Store tested points status
	
	# Last stable point at Eps biais :
	# --------------------------------
	itDichotomy=0
	while (d > Esp):
		itDichotomy=itDichotomy+1
		it = 0
		# writing entry file for eurostag
		while (True and it<4):
			try:
				FeditechFile(T,"simTest",U_nominal, MachineName)
				break
			except IOError:
				it += 1
				time.sleep(0.5)
				if it==4:
					print "ERROR: Impossible to write simTest.dta for ", MachineName
				pass
		print "Point test :", T
		[alpha,X, equi_value_used] = Fgroup(T,seqPath, dtaPath, echPath, P_boundaries, Q_boundaries, U_boundaries, U_nominal, P_nominal, Esp, equi_value_OK, equi_value_NOK)		
		print "alpha =", alpha
		testedPoints       = np.vstack( (testedPoints      , Conversion_si_pu(T,P_boundaries,Q_boundaries,U_boundaries)    ) )
		testedPointsStatus = np.vstack( (testedPointsStatus, np.array([alpha, equi_value_used]) ) )
		
		if (alpha == 0):
			#point is on stable side
			A = T             # New stable point
			T = (C+A)/2       # Updating test point
			print ".............. Cote Stable .............\n"
		else:
			#point is on unstable side
			C = T             # New unstable point
			T = (C+A)/2       # Updating test point
			print ".............. Cote instable .............\n"

		A_pu = Conversion_si_pu(A,P_boundaries,Q_boundaries,U_boundaries)
		C_pu = Conversion_si_pu(C,P_boundaries,Q_boundaries,U_boundaries)
		D_pu = C_pu - A_pu
		d = np.linalg.norm(D_pu)

		# Rest time for CPU :
		time.sleep(0.00000001)
		print "Dich. it.:", itDichotomy , "Distance point stable/instable : ", d,  " A ", A , " T " , T , " alpha ", alpha, "\n"
	
	B_pu = Conversion_si_pu(B,P_boundaries,Q_boundaries,U_boundaries)
	O_pu = Conversion_si_pu(O,P_boundaries,Q_boundaries,U_boundaries)
		
	print "Dernier point stable   : ", A, '\n'
	print "Dernier point instable : ", C, '\n'
	print "[OL AAA] Last point stable / unstable / boundary " , A, C, B 
	return A, testedPoints, testedPointsStatus 

def FeditechFile(X,file,U_nominal, MachineName):
	""" 
		Creates .ech Eurostag file (input Point of simulation)
		Inputs :
			- X = [P(MW), Q(Mvar), U(kV)] input point
			- file : name of .ech File 
		Output :
			- .ech file
		Used in :
			- Fexploration
			- Main
	"""
	#Converting data to string :
	#---------------------------
	Pin  = str(X[0])[:8]
	Qin  = str(X[1])[:8]
	Uin  = str(X[2])[:8]
	Unom = str(U_nominal)[:8]
	
	#Setting up file path :
	#----------------------
	filename = file + ".ech"
	path     = os.path.join("")
	filename = os.path.join(path, filename)

	with open(filename, 'w') as echfile:
		#Writing .ech file :
		#------------------
		echfile.write("HEADER     "+ time.strftime("%d/%m/%y") +" 5.1\n")
		echfile.write(" \nB \n \n"
			"9 1 0 0 1 1 20    0.005                                 4   0         100. \n \n"
			"AA A \nAA B \n \n")
		echfile.write("1A N1                                                                             "
			+ Unom.rjust(10) +
			"            1.       0.       0.       0.\n"
			"1B N2                                                                             "
			+ Unom.rjust(10) +
			"            1.       0.       0.       0.\n")
		print MachineName
		echfile.write(" \n5  N1                                        0.\n \n"
			"6 N1       N2      1       0.       0.\n \n"
			"G  " + MachineName.rjust(8) + " Y N1        -99999.       0.   99999.  -99999.       0.   99999. V"
			+ Uin.rjust(9) +
			" N1             1.       0.       0.\n \n")
		echfile.write("CH CHARGE   Y N2             0.       0."
			+ Pin.rjust(9) +
			"       0.       0."
			+ Qin.rjust(9) +
			"       0.       0.\n \n")

def FdomainBoundaries(dtaPath,nonnegVersion):
	"""  
		Extracts generators caracteristics and creates the study field from caracteristics
		Inputs :
			- dtaPath 		: location of generator parameters
			- nonnegVersion : indicates if the generator's domain should be constrained to P > 0
		Output :
			- Study boundaries 	: P_boundaries, Q_boundaries and U_boundaries(MW, Mvar, kV)
			- Unom 				: nominal tension (kV)
			- Pnomapp 			: Apparent nominal Power (MVar)
			- PnomMin 			: Minimal nominal Power (MVar)
		Used in : 
			- main
	"""
	#Creating local variables :
	#--------------------------
	P_boundaries = np.zeros(2)
	Q_boundaries = np.zeros(2)
	U_boundaries = np.zeros(2)

	#Opening specific machine dta file :
	#-----------------------------------
	with open(dtaPath) as Machinefile:
		#Reading file data :
		#-------------------
		lines    = Machinefile.readlines()
		
		Pnomapp = float( lines[3][19:26] )
		Unom    = float( lines[3][26:35] )
		PnomTurb = float( lines[3+3][55:62] ) 
		PnomAlt  = float( lines[3+3][64:71] ) 
		statRes  = float( lines[3+1][10:17])
		
		print "Pnom ", Pnomapp, "'",lines[3][19:26],"'"
		print "Unom", Unom, "'",lines[3][26:35],"'"
		print "PnomTurb", PnomTurb, "'",lines[3+3][55:62],"'"
		print "PnomAlt", PnomAlt, "'", lines[3+3][64:71],"'"
		print "Statoric resistance", statRes, "'", lines[3+1][10:17], ","
		
		PnomMinInit = min(Pnomapp,PnomTurb,PnomAlt)
		#Some units have bad PnomTurb and PnomAlt
		if PnomMinInit<0.1*Pnomapp or PnomMinInit<0.1*PnomTurb or PnomMinInit<0.1*PnomAlt :
			print "Business warning: Bad nominal powers (Is the unit a synchronous compenser?):", Pnomapp, PnomTurb, PnomAlt
			PnomMinInit = max(Pnomapp,PnomTurb,PnomAlt)
		
		#Computation of new Pnom taking into account that many units cannot
		#produce Pnom due to the statoric losses
		statResSI =  statRes*((Unom*1E3)*(Unom*1E3))/(Pnomapp*1E6)
		statLossesAtElectricalPnom = statResSI*(PnomMinInit*1E6/(Unom*1E3))*(PnomMinInit*1E6/(Unom*1E3))/1E6
		PnomMin = PnomMinInit - statLossesAtElectricalPnom
		print "Computed Pnom: ", PnomMin, " due to statoric losses ", statLossesAtElectricalPnom
		
	#Creating machine domain : 
	#-------------------------
	#Some units are stable up to very low and high voltages but it is not realistic. The interval is therefore reduced to concentrate the research on usefull part of the domain
	P_boundaries[:] = [-1.5*PnomMinInit,1.5*PnomMinInit]
	if nonnegVersion :
		P_boundaries[:] = [max(0,-1.5*PnomMinInit),1.5*PnomMinInit]
	Q_boundaries[:] = [-1.5*PnomMinInit,1.5*PnomMinInit]
	U_boundaries[:] = [0.8*Unom,1.2*Unom]

	return P_boundaries, Q_boundaries, U_boundaries, Unom, Pnomapp, PnomMin

def Fdirection(theta, phi, P_boundaries, Q_boundaries, U_boundaries, O, U_nominal, P_nominal):
	"""
		Computes boundary point in specified direction 
		Inputs :
			- theta : angle (in rad) on the P,Q plane 
			- phi   : angle (in rad) between U axis and direction
			Note : Spherical coordinates
			- P_boundaries, Q_boundaries, U_boundaries (MW, Mvar, kV) : Study field
			- O : Origin stable point of study
		Output :
			- B (MW, Mvar, kV) : point on domain boundary
		Used in :
		- FmonteCarlo
	"""

	# Creating local vars :
	# ---------------------
	O_pu = Conversion_si_pu(O, P_boundaries, Q_boundaries, U_boundaries)

	#Creating output :
	#-----------------
	B = np.zeros(3)

	# Moving Origin & normalizing :
	# -----------------------------
	Pmax = 1 - O_pu[0]
	Pmin = 0 - O_pu[0]
	Qmax = 1 - O_pu[1]
	Qmin = 0 - O_pu[1]
	Umax = 1 - O_pu[2]
	Umin = 0 - O_pu[2]

	#Computing direction :
	#---------------------
	x = m.sin(phi)*m.cos(theta) #P
	y = m.sin(phi)*m.sin(theta) #Q
	z = m.cos(phi) #U

	if 0<x:
		k_P = Pmax/max(1E-15*abs(Pmax),x)
	else:
		k_P = abs(Pmin/min(-1E-15*abs(Pmax),x))

	if 0<y:
		k_Q = Qmax/max(1E-15*abs(Qmax),y)
	else:
		k_Q = abs(Qmin/min(-1E-15*abs(Qmin),y))

	if 0<z:
		k_U = Umax/max(1E-15*abs(Umax),z)
	else:
		k_U = abs(Umin/min(-1E-15*abs(Umin),z))

	k = min(k_P, k_Q, k_U)

	B[:] = [k*x,k*y,k*z]

	# Moving back Origin :
	# --------------------
	B = B + O_pu

	# Converting to si from pu :
	# --------------------------
	B = Conversion_pu_si(B, P_boundaries, Q_boundaries, U_boundaries)

	return B

def Fraffinement(domain_data,faces,boundary_data,P_boundaries,Q_boundaries,U_boundaries,epsilon):
	""" 
		Check if corners need to be refined by projecting them on the convexHull of support points.
		The max distance of corner points to the convexHull of support point is also computed.
		Inputs :
			- domain_data 	: [n] list of PointDomain class containing corner points
			- faces 		: [n] list of faces class containing information of each faces 
			- boundary_data : [n] list of PointBoundary class containning support points
			- rest 			: not used
			- epsilon 		: criteria for belonging in plane
		Output : 
			- corners 		: Corners to be refined
			- origins 		: projection of corner on ConvexHull
			- directions 	: Direction to reach corner from origin
			- error_max 	: Max distance of corner points to ConvexHull
		Used in :
			- main (version 1 and 3)
	"""

	# Local variables :
	# -----------------
	# epsilon   = 0.0000001             # criteria for belonging in plane
	p_plane   = np.zeros(shape=(3))   # point in plane
	error     = 0.                    
	error_max = 0.

	# Outputs :
	# ---------
	directions = np.empty(shape=(0,2))  # directions in theta and phi
	origins    = np.empty(shape=(0,3))  # origins for the direction
	corners    = np.empty(shape=(0,3))  # corresponding corner in direction

	for i in range(0,len(domain_data)):
		# Finds which face includes point :
		# ---------------------------------
		index    = []   # index of three closest support point
		index_ns = []   # index of all faces including point
		for j in range(0,len(faces)):
			
			if np.all(np.isclose(faces[j].points,domain_data[i].point_pu),1).any():
				index_ns.append(j)      # Storing index

		index_ns = np.arange(0,len(boundary_data))
		if len(index_ns)>=3:

			# Computing closest boundary points to corner :
			# ---------------------------------------------
			closest_points = []
			for k in range(0,len(index_ns)):
				closest_points.append([index_ns[k], np.linalg.norm(domain_data[i].point_pu - boundary_data[index_ns[k]].point_pu)])
			closest_points = sorted(closest_points, key=lambda closest_points: closest_points[1])

			index.append(closest_points[0][0])
			index.append(closest_points[1][0])
			index.append(closest_points[2][0])

			# Creating plane from boundary points :
			# -------------------------------------
			n_plane = np.cross((boundary_data[index[1]].point_pu-boundary_data[index[0]].point_pu),(boundary_data[index[2]].point_pu-boundary_data[index[0]].point_pu))
			n_plane = n_plane/np.linalg.norm(n_plane)

			# Computing projection point : 
			# ----------------------------
			d_plane = abs(np.dot(n_plane,domain_data[i].point_pu) - np.dot(n_plane,boundary_data[index[0]].point_pu))
			p_plane = PointDomain(domain_data[i].point_pu - d_plane*n_plane, 'pu', P_boundaries,Q_boundaries,U_boundaries)

			# finding real projection
			if abs(np.dot(p_plane.point_pu-boundary_data[index[0]].point_pu,n_plane))<epsilon:
				p_plane = PointDomain(domain_data[i].point_pu - d_plane*n_plane, 'pu', P_boundaries,Q_boundaries,U_boundaries)
			else:
				p_plane = PointDomain(domain_data[i].point_pu + d_plane*n_plane, 'pu', P_boundaries,Q_boundaries,U_boundaries)

			d_plane = np.linalg.norm((domain_data[i].point_pu-p_plane.point_pu))
			error   = d_plane

			# Checking if projection is in triangle :
			# ---------------------------------------
			aire  = np.linalg.norm(np.cross(boundary_data[index[2]].point_pu - boundary_data[index[1]].point_pu
										  , boundary_data[index[2]].point_pu - boundary_data[index[0]].point_pu))/2
			alpha = np.linalg.norm(np.cross(boundary_data[index[2]].point_pu - p_plane.point_pu
										  , boundary_data[index[1]].point_pu - p_plane.point_pu))/(2*aire)
			beta  = np.linalg.norm(np.cross(boundary_data[index[2]].point_pu - p_plane.point_pu
										  , boundary_data[index[0]].point_pu - p_plane.point_pu))/(2*aire)
			gamma = 1 - alpha - beta

			if ~(0<=alpha<=1 and 0<=beta<=1 and 0<=gamma<=1):
				# Computing gravitycentre :
				# -------------------------
				a = np.linalg.norm(boundary_data[index[2]].point_pu - boundary_data[index[1]].point_pu)
				b =	np.linalg.norm(boundary_data[index[2]].point_pu - boundary_data[index[0]].point_pu)
				c = np.linalg.norm(boundary_data[index[0]].point_pu - boundary_data[index[1]].point_pu)

				p_plane = PointDomain(boundary_data[index[0]].point_pu*a/(a+b+c) 
									+ boundary_data[index[1]].point_pu*b/(a+b+c)
									+ boundary_data[index[2]].point_pu*c/(a+b+c)
									, "pu",P_boundaries,Q_boundaries,U_boundaries)				

			d_plane = np.linalg.norm((domain_data[i].point_pu-p_plane.point_pu))
			print "Coin : ", domain_data[i].point_pu
			print "Proj : ", p_plane.point_pu
			print "Erreur first : ", error

			if d_plane>epsilon:
				# Computing direction :
				# ---------------------
				if (domain_data[i].point_pu[1]-p_plane.point_pu[1])>=0:
					theta = m.acos((domain_data[i].point_pu[0]-p_plane.point_pu[0]) 
									/ sqrt((domain_data[i].point_pu[0]-p_plane.point_pu[0])**2
										 + (domain_data[i].point_pu[1]-p_plane.point_pu[1])**2))
				else:
					theta = 2*pi - m.acos((domain_data[i].point_pu[0]-p_plane.point_pu[0]) 
									/ sqrt((domain_data[i].point_pu[0]-p_plane.point_pu[0])**2
										 + (domain_data[i].point_pu[1]-p_plane.point_pu[1])**2))
				phi   = m.acos((domain_data[i].point_pu[2]-p_plane.point_pu[2])/np.linalg.norm(p_plane.point_pu - domain_data[i].point_pu))
				# Storing outputs : 
				# -----------------
				directions = np.vstack((directions, [theta,phi]))
				origins    = np.vstack((origins, p_plane.point_si))
				corners    = np.vstack((corners, domain_data[i].point_si))

			error = FcomputeError(domain_data[i].point_pu,boundary_data,error)
			if (error_max < error):
				error_max = error
			print "Erreur check : ", error_max

	return directions, origins, corners, error_max

	"""
		Create a cloud points to visualize next steps of computation :
		* Support points with normal vector
		* Corner points with their projection on the convexHull of the support points
		Inputs :
			- support_point : [n] list of PointBoundary Class
			- N : not used
			- P_boundaries, Q_boundaries, U_boundaries : boundaries of study (not used)
			- origin : stable origin used in the study
		Ouput  :
			- Visualisation of domain
		Used in :
			- main
	"""
	#Setting up visualiation :
	#-------------------------
	fig = plt.figure()
	ax = fig.gca(projection='3d')
	ax.set_aspect("equal")

	#Drawing domain boundaries :
	#---------------------------
	for s, e in combinations(np.array(list(product(P_boundaries,Q_boundaries,U_boundaries))), 2):
	    if np.sum(np.abs(s-e)) == (P_boundaries[1]-P_boundaries[0]):
	    	ax.plot3D(*zip(s,e), color="b")
	    elif np.sum(np.abs(s-e)) == (Q_boundaries[1]-Q_boundaries[0]):
	    	ax.plot3D(*zip(s,e), color="b")
	    elif np.sum(np.abs(s-e)) == (U_boundaries[1]-U_boundaries[0]):
	    	ax.plot3D(*zip(s,e), color="b")

	# Drawing vector associated to reference points :
	# -----------------------------------------------
	# for k in range(0,len(A)):
	# 	n = Arrow3D([A[k].point_si[0],A[k].point_si[0]+5*N[k,0]],[A[k].point_si[1],A[k].point_si[1]+5*N[k,1]],[A[k].point_si[2],A[k].point_si[2]+N[k,2]], mutation_scale=20, lw=1, arrowstyle="-|>", color="r")	
	# 	ax.add_artist(n)

	# Drawing points :
	# ----------------
	colors = iter(cm.rainbow(np.linspace(0, 1, len(corners))))

	for k in range(0,len(A)):
		ax.scatter(A[k].point_si[0],A[k].point_si[1],A[k].point_si[2], color='g',s=20)
	for k in range(0,len(corners)):
		c = next(colors)
		ax.scatter(corners[k,0],corners[k,1],corners[k,2],color=c, zdir='A[:,2]',s=50)
		ax.scatter(origins[k,0],origins[k,1],origins[k,2],color=c, zdir='A[:,2]',s=50)
		a = Arrow3D([origins[k,0],corners[k,0]],[origins[k,1],corners[k,1]],[origins[k,2],corners[k,2]], mutation_scale=10, lw=1, arrowstyle="-|>", color=c)
		ax.add_artist(a)
		plt.draw()

	ax.scatter(O[0],O[1],O[2],color='g',s=2)
	plt.draw()
	#Display figure :
	#----------------
	ax.set_xlabel('P', fontsize='xx-large')
	ax.set_ylabel('Q', fontsize='xx-large')
	ax.set_zlabel('U', fontsize='xx-large')
	# fig.suptitle(MachineName, fontsize='xx-large')
	fig.savefig('QuickViz')
	plt.draw()

def FcomputeError(corner_point,boundary_data,error):
	"""
		Check if previous calculated error is the minimum distance to boundary domain
		Inputs :
			- corner_point 	: studied point
			- boundary_data : points of the boundary
			- error 		: distance between corner_point and its custom projection on boundary domain
		Outputs :
			- dist_point 		: minimum distance of corner_point to the boundary domain
		Used in :
			- Fraffinement
	"""
	dist_point = error   # Initialising dist_point
	# Checking the distance of corner_point from each boundary points
	for i in range(0,len(boundary_data)):
		if np.linalg.norm(corner_point - boundary_data[i].point_pu)<dist_point:
			# Updating dist_point if a new min is found
			dist_point = np.linalg.norm(corner_point - boundary_data[i].point_pu)
	return dist_point 

def FMonteCarlo(nbre_point,seqPath, dtaPath, echPath, stableOrigin_si , U_nominal, P_nominal ,P_boundaries,Q_boundaries,U_boundaries, precision, MachineName, equi_value_OK, equi_value_NOK, epsilon):
	"""
		Checks if specified points are stable or not, constructs convex hull and reduces domain
		Inputs :
			- nbre_point : Number of points
			- files for eurostag
			- initial stability point
			- study domain
		Ouput  :
			- stable points 
			- unstable points
			- status
		Used in :
			- main
	"""
	# Creating output :
	# -----------------
	points_stable         = np.zeros(shape=(0,3))
	is_last_stable_point  = np.zeros(shape=(0,1), dtype=np.bool_ )
	points_instable       = np.zeros(shape=(0,3))
	points_instable_in    = np.zeros(shape=(0,3))
	points_unknown        = np.zeros(shape=(0,3))
	points_unknown_in     = np.zeros(shape=(0,3))

	status_stable_in   = np.zeros(shape=(0,2))
	status_unknown_in  = np.zeros(shape=(0,2))
	status_unstable_in = np.zeros(shape=(0,2))
	
	status_stable   = np.zeros(shape=(0,2))
	status_unknown  = np.zeros(shape=(0,2))
	status_unstable = np.zeros(shape=(0,2))
	
	#Isocaedron sampling would be better...
	nbPhis = np.ceil(np.sqrt(nbre_point)/8) #(Integral of abs(sin) between -pi and pi is 4)
	phis = np.linspace(0,pi,num=max(3,nbPhis), endpoint=True)
	indPhi = 0;
	
	#For all directions, computes stable, unstable and unknown points
	for phi in phis:
		indPhi = indPhi+1;
		nbThetas = max(1,np.ceil( np.abs( 2*np.sin(phi)) * nbPhis ))
		thetas = np.linspace(-pi,pi,num=nbThetas, endpoint=False)
		print "[OL AAAAA] Phi indice/# and value: " , indPhi, "/", nbPhis , phi, " # of thetas: ", thetas.shape[0], ". Current number of points (stable, unknown, unstable, total): ", points_stable.shape[0],  points_unknown.shape[0],  points_instable.shape[0], (points_stable.shape[0] + points_unknown.shape[0] + points_instable.shape[0])
		for theta in thetas:
			boundaryPoint = Fdirection(theta,phi,P_boundaries, Q_boundaries, U_boundaries, stableOrigin_si, U_nominal, P_nominal)
			lastStablePoint, testedPoints, testedPointsStatus  = Fexploration(stableOrigin_si, boundaryPoint, precision, seqPath, dtaPath, echPath, U_nominal, P_nominal, P_boundaries, Q_boundaries, U_boundaries, MachineName, equi_value_OK, equi_value_NOK)
			lastStablePoint_pu = Conversion_si_pu(lastStablePoint, P_boundaries, Q_boundaries, U_boundaries)
			print "testedPoints: ", testedPoints
			print "testedPointsStatus: ", testedPointsStatus
			print "last stable point: ", lastStablePoint_pu

			distance = np.zeros(shape=(0,1))
			indices  = np.zeros(shape=(0,1),dtype=np.int64)
			for indPoint in range(0,np.shape(testedPointsStatus)[0]):
				alpha = testedPointsStatus[indPoint,0]
				if (alpha == 0):
					points_stable        = np.vstack( (points_stable       , testedPoints[indPoint,:])                                       )
					is_last_stable_point = np.vstack( (is_last_stable_point, np.zeros(shape=(1,1), dtype=np.bool_ ))                         )
					distance             = np.vstack( (distance            , np.linalg.norm( testedPoints[indPoint,:] - lastStablePoint_pu )))
					indices              = np.vstack( (indices             , is_last_stable_point.shape[0]-1 )                               )
					status_stable = np.vstack( (status_stable, testedPointsStatus[indPoint,:] ) )
				elif (alpha == 1):
					points_unknown = np.vstack((points_unknown,testedPoints[indPoint,:]))
					status_unknown = np.vstack( (status_unknown, testedPointsStatus[indPoint,:] ) )
				elif (alpha == 2):
					points_instable = np.vstack( (points_instable,testedPoints[indPoint,:]))
					status_unstable = np.vstack( (status_unstable, testedPointsStatus[indPoint,:] ) )
				else:
					print "Error: Unknown status ", alpha

			if distance.shape[0]>0:
				if min(distance)>epsilon:
					print "ERROR: the distance should be null in FMonteCarlo"
				is_last_stable_point[indices[np.argmin(distance)]] = True
				#Add a dummy unknown point just after the last stable point
				stableOrigin_pu = Conversion_si_pu(stableOrigin_si, P_boundaries, Q_boundaries, U_boundaries)
				first_unknown_point = lastStablePoint_pu + epsilon*10*(lastStablePoint_pu-stableOrigin_pu)/np.linalg.norm(lastStablePoint_pu-stableOrigin_pu)
				print "Adding 'First unknown point' ", first_unknown_point, ", just after " ,  lastStablePoint_pu, " in opposite direction from stable origin ", stableOrigin_pu
				points_unknown = np.vstack((points_unknown, first_unknown_point))
				status_unknown = np.vstack( (status_unknown, [ 2 , equi_value_OK + 10*epsilon  ] ) )

	print "Stable points found by MC: "
	print points_stable
	print "Unknown points found by MC: "
	print points_unknown
	print "Unstable points found by MC: "
	print points_instable
	
	#Creates convex domain 
	points_stable_OK = points_stable.copy()
	if (points_stable.shape[0]>0):
		hull = ConvexHull(points_stable)
		equation_reel = hull.equations
		for i in range(0,points_instable.shape[0]):
			all_inside=True
			for j in range(0,equation_reel.shape[0]):
				if (np.dot(points_instable[i,:],equation_reel[j,:3]) > epsilon - equation_reel[j,3] ):
					all_inside=False
					break
			if all_inside :
				points_instable_in = np.vstack((points_instable_in,points_instable[i,:]))
				status_unstable_in = np.vstack((status_unstable_in,status_unstable[i,:]))

		for i in range(0,points_unknown.shape[0]):
			all_inside=True
			for j in range(0,equation_reel.shape[0]):
				if (np.dot(points_unknown[i,:],equation_reel[j,:3]) > epsilon - equation_reel[j,3] ):
					all_inside=False
					break
			if all_inside :
				points_unknown_in = np.vstack((points_unknown_in,points_unknown[i,:]))
				status_unknown_in = np.vstack((status_unknown_in,status_unknown[i,:]))
		
		#Removing all stable whose removal allows to remove at least one unstable point
		for i in range(0,points_instable.shape[0]):
			j = 0
			pointins_inDomain = True
			while pointins_inDomain and j<points_stable_OK.shape[0]:
				points_test = np.delete(points_stable_OK, j, 0)
				try:
					hull = ConvexHull(points_test)
					points_test = np.vstack((points_test,points_instable[i,:]))
					try:
						hull_new = ConvexHull(points_test)
						if list(hull_new.vertices) != list(hull.vertices):
							pointins_inDomain = False
							points_stable_OK = np.delete(points_stable_OK, j, 0) 
					except:
						print "Second ConvHull failure while trying to remove stable points"
				except:
					print "First ConvHull failure while trying to remove stable points"
				j+=1
				
	else:
		points_instable_in = np.zeros(shape=(0,3))
		points_unknown_in  = np.zeros(shape=(0,3))

	return points_stable, points_instable_in, points_unknown_in, points_stable_OK, is_last_stable_point, status_stable, status_unstable_in, status_unknown_in

# Main Program :
# --------------
def main(version, visualisation, nbr_points, nonnegVersion):
	"""
	Main program, compute 3D stable domain of generator :
	Inputs : 
		- version : which version of the program is used 
		0 : simple   (Initialisation + 2*refinement) 
		1 : sampling (random points, but current version deterministic search direction)
		2 : write specified ech file for manual simulation
		3 : criteria based on error and max iteration
		4 : simple+  (Initiation + 2*refinement + corners)
		- visualisation : on or off
		0 : off
		1 : on
	Ouputs :
		- for each stage a .off output is created
		- a .csv file is created containing all planes
	Used in : 
		- IndusMachineDomaine.py
	"""
	print "Beginning of main in MachineStableDomaineSearch"
	time_start = time.time()
	
	# Setting up visualization :
	# --------------------------
	fig = plt.figure()
	ax = fig.add_subplot(111, projection='3d')

	# Parameters :
	# -----------
	p = 6*2               # number of points on boundary
	iteration = 0       # number of iteration
	error = 0           # initialisation of error

	# Path to data files :
	# --------------------
	dtaFile = os.path.join("simTest.dta")
	echFile = os.path.join("simTest.ech")
	seqFile = os.path.join("simTest.seq")
	
	#Creating data arrays :
	#----------------------
	boundary_data = []
	domain_data   = []
	A    = np.zeros(shape=(p,3)) 	# Store boundary points
	N    = np.zeros(shape=(p,3)) 	# Store boundary normal vector
	O    = np.zeros(shape=3) 		# Stable origin used
	O_pu = np.zeros(shape=3) 		# Stable origin in p.u 

	# Creating study domains from machine data :
	# -----------------------------------------
	P_boundaries, Q_boundaries, U_boundaries, U_nominal, SN, P_nominal = FdomainBoundaries(dtaFile,nonnegVersion)
	if os.name == 'nt':
		MachineName = os.getcwd().split("\\")[-1]
	else:
		MachineName = os.getcwd().split("/")[-1]
	print "'"+MachineName+"'";
	MachineRefName = MachineName
	
	print "Domaine d'etude :"
	print P_boundaries
	print Q_boundaries
	print U_boundaries, "\n"

	# Computing precision used in program from machine data and setting equilibrium value :
	# -------------------------------------------------------
	print "Precision:"
	pas = max(0.01,P_nominal*10**-4)
	print "Step: ", pas, "\n"
	precision_vect = Conversion_si_pu([P_boundaries[0] +  pas,Q_boundaries[0] + pas,U_boundaries[0] + pas*U_nominal/400.],P_boundaries, Q_boundaries, U_boundaries)
	print "Vector: ", precision_vect, "\n"
	precision = np.linalg.norm(precision_vect)
	#Width of the angle for the tangent plane computation of the first step.
	firstStepPrecision = precision
	print "Norm: ", precision, "\n"
	epsilon_refinement   = 0.0000001             # criteria for belonging in plane
	print "Epsilon refinement: ", epsilon_refinement, "\n"
	#Equilibrium value under which the starting point is considered as stable
	#Eurostag does not allow to check below 0.01
	equi_value_OK = 0.001
	#Equilibrium value under which the starting point is considered as unstable
	#equi_value_NOK = 0.05
	equi_value_NOK = 0.01
	
	O[:] = [P_nominal*0.7,0,U_nominal]
	O_pu = Conversion_si_pu(O,P_boundaries,Q_boundaries,U_boundaries)
	print "Origin SI/pu ", O, " / ", O_pu

	FeditechFile([P_nominal,0,U_nominal],"simTest",U_nominal, MachineName)
	print "Check stability of the nominal point ", [P_nominal,0,U_nominal]
	nominalPointSI = [P_nominal,0,U_nominal]
	nominalPointPU = Conversion_si_pu(nominalPointSI,P_boundaries,Q_boundaries,U_boundaries)
	[alphaNominal,X, equi_value_used_Nominal] = Fgroup(nominalPointSI, seqFile, dtaFile, echFile, P_boundaries, Q_boundaries, U_boundaries, U_nominal, P_nominal, precision, equi_value_OK, equi_value_NOK)
	if alphaNominal!=0 :
		tolTempOK  = min(1,2*equi_value_used_Nominal)
		tolTempNOK = max(2*tolTempOK,equi_value_NOK)
		print "Business Warning: Nominal point is not stable: ", alphaNominal, ",", X, ",", equi_value_used_Nominal, ". The tolerances are increased ", equi_value_OK, " and ", equi_value_NOK, " to " , tolTempOK, " and ", tolTempNOK
		equi_value_OK  = tolTempOK
		equi_value_NOK = tolTempNOK

	# Choosing stable origin inside domaine : 
	# ---------------------------------------
	FeditechFile(O,"simTest",U_nominal, MachineName)
	print "Check stability of the origin"
	[alpha,X, equi_value_used_O] = Fgroup(O, seqFile, dtaFile, echFile, P_boundaries, Q_boundaries, U_boundaries, U_nominal, P_nominal, precision, equi_value_OK, equi_value_NOK)
	if alpha!=0 :
		tolTempOK  = min(1,2*equi_value_used_Nominal)
		tolTempNOK = max(2*tolTempOK,equi_value_NOK)
		print "Business Warning: Origin is not a stable point: ", alpha, ",", X, ",", equi_value_used_O, ". The tolerances are increased ", equi_value_OK, " and ", equi_value_NOK, " to " , tolTempOK, " and ", tolTempNOK
		equi_value_OK  = tolTempOK
		equi_value_NOK = tolTempNOK
	
	time_stop = time.time()
	print "[Elapsed time] Initialization ", (time_stop-time_start)
	time_start=time_stop
	
	# ======================================================= #
	#                         MAIN PROGRAM                    #
	# ======================================================= #

	# Version 1 : Computing stable simulation domain using sampling
	# the number of points can be specified in FMonteCarlo
	# -------------------------------------------------------------
	if (version == 1):
		print "VERSION: Random"

		#Si groupe deja traite recuperation des donnees dans le pysav
		#sinon, appel de la fonction FMonteCarlo pour déterminer points stables et instables dans toutes les directions
		pySavFile = 'simulation_results.pysav'
		if os.path.exists(pySavFile):
			with open(pySavFile) as f:  # Python 3: open(..., 'rb')
				stable_points_initial_pu, unstable_points_initial_in_pu, unknown_points_initial_pu, stable_points_initial_pu_OK, is_last_stable_point, status_stable, status_unstable, status_unknown = pickle.load(f)
		else:
			stable_points_initial_pu, unstable_points_initial_in_pu, unknown_points_initial_pu, stable_points_initial_pu_OK, is_last_stable_point, status_stable, status_unstable, status_unknown = FMonteCarlo(nbr_points,seqFile, dtaFile, echFile,O, U_nominal, P_nominal,P_boundaries,Q_boundaries,U_boundaries,precision, MachineName, equi_value_OK, equi_value_NOK, epsilon_refinement)
			with open(pySavFile, 'w') as f:  # Python 3: open(..., 'wb')
				pickle.dump([stable_points_initial_pu, unstable_points_initial_in_pu, unknown_points_initial_pu, stable_points_initial_pu_OK, is_last_stable_point, status_stable, status_unstable, status_unknown], f)
		
		print "End of simulations"
		time_stop = time.time()
		print "[Elapsed time] Simulations ", (time_stop-time_start)
		time_start=time_stop
		
		#Add nominal point to stable points
		stable_points_initial_pu = np.vstack( (stable_points_initial_pu, nominalPointPU) )
		is_last_stable_point = np.vstack( (is_last_stable_point, False) )
		status_stable = np.vstack( (status_stable , np.array([alphaNominal, equi_value_used_Nominal]) ) )
		
		#Checks
		if stable_points_initial_pu.shape[0] != status_stable.shape[0]:
			print "Error on stable_points_initial_pu"
		if unstable_points_initial_in_pu.shape[0] != status_unstable.shape[0]:
			print "Error on unstable_points_initial_in_pu"
		if unknown_points_initial_pu.shape[0] != status_unknown.shape[0]:
			print "Error on unknown_points_initial_pu"
		if status_stable.shape[0]>0 and status_unknown.shape[0]>0:
			if np.max(status_stable[:,1])>np.min(status_unknown[:,1]):
				print "Error: separation problem between stable and unknown ", np.max(status_stable[:,1]) , "," , np.min(status_unknown[:,1])
		if status_unknown.shape[0]>0 and status_unstable.shape[0]>0:
			if np.max(status_unknown[:,1])>np.min(status_unstable[:,1]) :
				print "Error: separation problem between unknown and unstable ", np.max(status_unknown[:,1]) , "," , np.min(status_unstable[:,1])
		
		unstable_points_initial_in_si   = np.zeros(shape=(unstable_points_initial_in_pu.shape[0]  ,3))		
		for i in range(0,unstable_points_initial_in_pu.shape[0]):
			unstable_points_initial_in_si[i,:] = Conversion_pu_si(unstable_points_initial_in_pu[i,:], P_boundaries, Q_boundaries, U_boundaries)
			point_filename = MachineName + "_" +str(i)

		print "Last stable boundary points in each direction as found by MC (pu):"
		stable_boundary_points_initial_pu = stable_points_initial_pu[ np.where(is_last_stable_point)[0], :]
		print stable_boundary_points_initial_pu
		
		domainIndicator = np.ones(shape=(2,1))
		finalDomain=-1
		for indDomain in range(1):
			if indDomain==0:
				print "///////////////////////////////////////////"
				print "DOMAIN COMPUTATION WITH UNKNOWN AS UNSTABLE"
			else:
				print "///////////////////////////////////////////"
				print "DOMAIN COMPUTATION WITH UNKNOWN AS STABLE  "
			
			time_stop = time.time()
			print "[Elapsed time] Before domain computation ", (time_stop-time_start)
			time_start=time_stop
			
			stable_boundary_points_final_pu  = np.zeros(shape=(0,3))
			stable_points_final_pu  = np.zeros(shape=(0,3))
			stable_points_outside_final_pu  = np.zeros(shape=(0,3))
			unknown_points_final_pu  = np.zeros(shape=(0,3))
			unstable_points_final_pu = np.zeros(shape=(0,3))
			initial_stable_boundary_points_pu = np.zeros(shape=(0,3))
			
			final_faces_pu = list()

			equation_reel_or=np.zeros(shape=(0,0));
			if (stable_points_initial_pu.shape[0]>0):
				convH = ConvexHull(stable_points_initial_pu)
				equation_reel_or = convH.equations
				
				#Initial domain creation, used for controls
				#First find a point on the plan
				pointInPlan = np.zeros(equation_reel_or[:,0:3].shape)
				for i in range(0,equation_reel_or.shape[0]):
					ind=np.argmax(abs(equation_reel_or[i,0:3]))
					pointInPlan[i,ind]=-equation_reel_or[i,3]/equation_reel_or[i,ind]
				print "Original equations:"
				print equation_reel_or[:,0:3]
				initial_faces_pu, initial_stable_boundary_points_pu = CreateMachineDomain.FdomainCreation(pointInPlan,equation_reel_or[:,0:3],[0,1],[0,1],[0,1],O_pu,precision,False)	
				print "Number of directions: ", sum(is_last_stable_point==True)[0] , ", number of corner points: ", initial_stable_boundary_points_pu.shape[0], " Points lost due to non-convexity: ", sum(is_last_stable_point)[0]-initial_stable_boundary_points_pu.shape[0]
				print "Initial corners :"
				print initial_stable_boundary_points_pu
				
				# Checking if points of convex hull are inside domain :
				# -----------------------------------------------------
				for point in convH.points:
					for i in range(0,equation_reel_or.shape[0]):
						if (np.dot(point,equation_reel_or[i,:3]) > epsilon_refinement - equation_reel_or[i,3] ):
							print "ERROR: the stable point ", point, " is not in the convex hull of convex points because of inequality ", equation_reel_or[i,:]
				
				#Domain reduction to remove the unstable point.
				# Checking for duplicate and for inclusion of origin :
				# ------------------------
				print "Check inclusion of the initial point in all half-spaces defined by the ", equation_reel_or.shape[0] , " inequalities"
				doublon = False
				for i in range (0,equation_reel_or.shape[0]):
					doublon = False
					for j in range(i+1,len(convH.equations)):
						if np.all(equation_reel_or[i] == equation_reel_or[j]):
							doublon = True
							print "ConvHull returned a doublon which is eliminated"
							break
					if doublon == False:
						if (np.dot(O_pu,equation_reel_or[i,:3]) > epsilon_refinement - equation_reel_or[i,3]):
							print "WARNING: The initial point (in pu:", O_pu, ") is not in the stable half-space of defined by inequality ", i ," the following inequality is removed: ", equation_reel_or[i,:], ". A tentative to find a new initial point will be made after domain reduction" 
						equation_reel_or = np.vstack((equation_reel_or,convH.equations[i]))

				time_stop = time.time()
				print "[Elapsed time] One domain computation up to domain reduction", (time_stop-time_start)
				time_start=time_stop
				# For each unstable point inside the domain, find the closest border and reduce the domain:
				# --------------------------------------------
				if status_unknown[:,1].shape[0]>0:
					min_unknown_mismatch = min(status_unknown[:,1])
					max_unknown_mismatch = max(status_unknown[:,1])
				else :
					min_unknown_mismatch = equi_value_OK
					max_unknown_mismatch = equi_value_NOK
				
				time_stop = time.time()
				print "[Elapsed time] Before domain reduction ", (time_stop-time_start)
				time_start=time_stop
				
				if indDomain==0:
					nbLoops=1
				else:
					nbLoops=10
				indLoop=0
				while indLoop < nbLoops :
					indLoop = indLoop+1
					nb_stable_outside_after=0;
					nb_unknown_inside_after=0;
					nb_unstable_inside_after=0;

					equation_reel = equation_reel_or.copy()
					points_to_be_excluded          = np.vstack( (unstable_points_initial_in_pu, unknown_points_initial_pu ) )
					status_points_to_be_excluded   = np.vstack( (status_unstable, status_unknown ) )
					indSortPoints = np.argsort(-status_points_to_be_excluded[:,1])
					points_to_be_excluded = points_to_be_excluded[indSortPoints,:]
					status_points_to_be_excluded = status_points_to_be_excluded[indSortPoints,:]
					if indDomain==1:
						indMax = np.int64(np.ceil( points_to_be_excluded.shape[0]* (indLoop*1.0) / (1.0*nbLoops) ))
						print indMax
						points_to_be_excluded = points_to_be_excluded[ range(0,indMax) , : ]
						status_points_to_be_excluded = status_points_to_be_excluded[ 0:indMax , : ]
					
					#s'il y a des points instables a exclure
					if status_points_to_be_excluded.shape[0]>0:
						mismatchThreshold = status_points_to_be_excluded[ -1 , 1 ]
						print "#Points to be excluded in loop (", indDomain, ",", indLoop , ") ", points_to_be_excluded.shape[0] , ". Min mismatch amoung them:", status_points_to_be_excluded[ -1 , 1 ]

						found_negative_distance= (points_to_be_excluded.shape[0]>0)
						unmovable_constraint = np.zeros(shape=(equation_reel.shape[0],1))
						tested_point = np.zeros(shape=(points_to_be_excluded.shape[0],1))
						eliminatedStablePoint = np.zeros(shape=(stable_points_initial_pu.shape[0],1))
						continue_reduction=True
						nbPointEliminated=0
						nb_stable_outside_after = 0
						tooManyEliminated=False
						while found_negative_distance and continue_reduction:
							nbPointEliminated = nbPointEliminated+1
							argmax_projections =            -1*np.ones(shape=(points_to_be_excluded.shape[0],1),dtype=np.int64)
							max_projections    = -float('inf')*np.ones(shape=(points_to_be_excluded.shape[0],1))
							#Compute all distances
							for i in range(0,points_to_be_excluded.shape[0]):
								if tested_point[i]==0:
									point = points_to_be_excluded[i,:]
									for j in range(0,equation_reel.shape[0]):
										if unmovable_constraint[j]==0:
											projection = np.dot(point,equation_reel[j,:3]) +  equation_reel[j,3]
											if (projection>max_projections[i]):
												argmax_projections[i] = j
												max_projections[i]    = projection
							if False :
								#Select lowest distance (highest in absolute value)
								#This heuristics minimize the number of steps (and of "useless" reductions).
								argmax_point_projections = np.argmin( max_projections )
							else :
								#Select highest negative value (lowest in absolute value)
								#This heuristics minimize the size of each reduction, thus the risk of damaging the domain by picking up a bad plane.
								max_projections_select = max_projections
								max_projections_select[ np.where(max_projections>=-epsilon_refinement) ] = -float('inf')
								argmax_point_projections = np.argmax( max_projections )
								
							min_projection           =    max_projections[ argmax_point_projections, 0 ]
							argmax_min_projection    = argmax_projections[ argmax_point_projections, 0 ]
							tested_point[argmax_point_projections]=1
							if min_projection>-float('inf')/2 and min_projection<-epsilon_refinement:
								newRHS = equation_reel[argmax_min_projection,3] - ( min_projection - epsilon_refinement )
								projection = np.dot(nominalPointPU,equation_reel[argmax_min_projection,:3]) +  newRHS
								#Check that the nominal point is still included. If not, stop.
								if projection>epsilon_refinement :
									print "The nominal point would be excluded by the reduction with a margin of ", projection , " following a shift of ",  (- ( min_projection - epsilon_refinement )), ". The reduction is stopped after ", nbPointEliminated, " point eliminations"
									unmovable_constraint[argmax_min_projection]=1
									if sum(unmovable_constraint)==unmovable_constraint.shape[0]:
										continue_reduction=False
								else :
									#Check the amount of stable points excluded. If too high, stop
									#How many stable points were excluded ?
									for iexc in range(0,stable_points_initial_pu.shape[0]):
										if eliminatedStablePoint[iexc]==0:
											max_projection = 0
											argmax_projection = -1
											point = stable_points_initial_pu[iexc,:]
											projection = np.dot(point,equation_reel[argmax_min_projection,:3]) +  newRHS
											if projection>epsilon_refinement:
												nb_stable_outside_after=nb_stable_outside_after+1
												eliminatedStablePoint[iexc]=1
									if nb_stable_outside_after>0.5*stable_points_initial_pu.shape[0]:
										continue_reduction=False
										tooManyEliminated=True
									else:
										#Change the rhs of corresponding equation and continue
										print "Margin reduced of ", min_projection, " on inequality ", argmax_min_projection,' ', equation_reel[argmax_min_projection,] , " because of point ", argmax_point_projections, ", ", points_to_be_excluded[argmax_point_projections,:], ". Current # of eliminated stable:", nb_stable_outside_after
										equation_reel[argmax_min_projection,3] = newRHS
							else :
								found_negative_distance=False
						
						time_stop = time.time()
						print "[Elapsed time] Final domain check ", (time_stop-time_start)
						time_start=time_stop
					
						#Handling of the case where the initial point is not inside anymore
						max_projection = -float('inf')
						argmax_projection = -1
						for j in range(0,equation_reel.shape[0]):
							projection = np.dot(O_pu,equation_reel[j,:3]) +  equation_reel[j,3]
							if projection>max_projection:
								argmax_projection=j
								max_projection = projection
						if max_projection>epsilon_refinement:
							print "The original initial point is now outside ", O_pu, ". Highest margin inequality ", argmax_projection, ",", equation_reel[argmax_projection,:], ',', max_projection
							objarr = np.array([0,0,0,1])
							inarr = np.hstack( ( equation_reel[:,0:3] , -np.ones( shape=(equation_reel.shape[0],1 ) ) ) )
							ubarr = -equation_reel[:,3]
							print objarr
							print inarr
							print ubarr
							res=scipy.optimize.linprog( objarr , A_ub = inarr, b_ub = ubarr,
								bounds=( (0, 1), (0, 1), (0, 1), (None, None)), options={"disp": True} ) 
							print res
							if res.status==0 :
								O_pu = res.x[0:3]
								O    = Conversion_pu_si(O_pu, P_boundaries, Q_boundaries, U_boundaries)
								print "The new initial point is ", O_pu
							else :
								print "Error: impossible to find a new initial point"
							max_projection = -float('inf')
							argmax_projection = -1
							for j in range(0,equation_reel.shape[0]):
								projection = np.dot(O_pu,equation_reel[j,:3]) +  equation_reel[j,3]
								if projection>max_projection:
									argmax_projection=j
									max_projection = projection
							if max_projection>epsilon_refinement:
								print "ERROR The new initial point is now outside ", O_pu, ". Highest margin inequality ", argmax_projection, ",", equation_reel[argmax_projection,:], ',', max_projection
								
						#Final domain creation
						#First find a point on the plan
						pointInPlan = np.zeros(shape=(equation_reel.shape[0],3))
						for i in range(0,equation_reel.shape[0]):
							ind=np.argmax(abs(equation_reel[i,0:3]))
							pointInPlan[i,ind]=-equation_reel[i,3]/equation_reel[i,ind]

						final_faces_pu, stable_boundary_points_final_pu = CreateMachineDomain.FdomainCreation(pointInPlan,equation_reel[:,0:3],[0,1],[0,1],[0,1],O_pu,precision,False)	
						print "# of corners (Initial/Final): ", initial_stable_boundary_points_pu.shape[0], "/", stable_boundary_points_final_pu.shape[0]
						
						#Are new corners OK (consistency check)
						for i in range(0,stable_boundary_points_final_pu.shape[0]):
							max_projection = -float('inf')
							argmax_projection = -1
							point = stable_boundary_points_final_pu[i,:]
							for j in range(0,equation_reel.shape[0]):
								projection = np.dot(point,equation_reel[j,:3]) +  equation_reel[j,3]
								if projection>max_projection:
									argmax_projection=j
									max_projection = projection
							if max_projection>epsilon_refinement:
								print "ERROR: Corner point outside. ", stable_boundary_points_final_pu[i], ". Highest margin inequality ", argmax_projection, ",", equation_reel[argmax_projection,:], ',', max_projection
								nb_unknown_inside_after=nb_unknown_inside_after+1
						
						#How many stable points were excluded ?
						nb_stable_outside_after=0
						min_excluded_stable_mismatch = float('inf')
						for i in range(0,stable_points_initial_pu.shape[0]):
							max_projection = 0
							argmax_projection = -1
							point = stable_points_initial_pu[i,:]
							for j in range(0,equation_reel.shape[0]):
								projection = np.dot(point,equation_reel[j,:3]) +  equation_reel[j,3]
								if projection>max_projection:
									argmax_projection=j
									max_projection = projection
							if max_projection>epsilon_refinement:
								print "Stable point ", point , "excluded by domain reduction due to inequality ", argmax_projection, ",", equation_reel[argmax_projection,:], ' with a margin of ', max_projection
								nb_stable_outside_after=nb_stable_outside_after+1
								min_excluded_stable_mismatch = np.min( [min_excluded_stable_mismatch, status_stable[i,1]] )
								stable_points_outside_final_pu = np.vstack( (stable_points_outside_final_pu, point ) )
						
						#How many unknown points remain ?
						max_included_unknown_mismatch = -float('inf')
						nb_unknown_inside_after=0
						for i in range(0,unknown_points_initial_pu.shape[0]):
							max_projection = -float('inf')
							argmax_projection = -1
							point = unknown_points_initial_pu[i,:]
							for j in range(0,equation_reel.shape[0]):
								projection = np.dot(point,equation_reel[j,:3]) +  equation_reel[j,3]
								if projection>max_projection:
									argmax_projection=j
									max_projection = projection
							if max_projection<-epsilon_refinement:
								if indDomain==0:
									print "Unknown point still inside after domain reduction. Lowest margin inequality ", argmax_projection, ",", equation_reel[argmax_projection,:], ',', max_projection
								max_included_unknown_mismatch = np.max( [max_included_unknown_mismatch, status_unknown[i,1]] )
								nb_unknown_inside_after=nb_unknown_inside_after+1
								
						#How many unstable points remain ?
						max_included_unstable_mismatch = -float('inf')
						nb_unstable_inside_after=0
						for i in range(0,unstable_points_initial_in_pu.shape[0]):
							max_projection = -float('inf')
							argmax_projection = -1
							point = unstable_points_initial_in_pu[i,:]
							for j in range(0,equation_reel.shape[0]):
								projection = np.dot(point,equation_reel[j,:3]) +  equation_reel[j,3]
								if projection>max_projection:
									argmax_projection=j
									max_projection = projection
							if max_projection<-epsilon_refinement:
								print "WARNING: Unstable point still inside after domain reduction due to inequality ", argmax_projection, ",", equation_reel[argmax_projection,:], ',', max_projection
								max_included_unstable_mismatch = np.max( [max_included_unstable_mismatch, status_unstable[i,1]] )
								nb_unstable_inside_after=nb_unstable_inside_after+1
						#Break if threshold is OK
						print "In loop ", indDomain, " ", indLoop , ": Trying to remove: ", points_to_be_excluded.shape[0] , " out of " , (unstable_points_initial_in_pu.shape[0]+unknown_points_initial_pu.shape[0]) ," points. Stable excluded after: ", nb_stable_outside_after, " out of ", stable_points_initial_pu.shape[0] , " with mismatch ", mismatchThreshold
						if tooManyEliminated :
							print "stop at threshold ", mismatchThreshold, " because too many stable points were removed: ", nb_stable_outside_after, " limit: ", 0.5*stable_points_initial_pu.shape[0]
							break
					else:
						min_excluded_stable_mismatch=float("inf")
						max_included_unknown_mismatch=float("-inf")
						max_included_unstable_mismatch=float("-inf")
						stable_boundary_points_final_pu = initial_stable_boundary_points_pu
						stable_points_outside_final_pu = np.zeros(shape=(0,3))
						print "No point to exclude"
				#End of while
				
				time_stop = time.time()
				print "[Elapsed time] One domain computation up to the end of domain reduction", (time_stop-time_start)
				time_start=time_stop
				
				stable_boundary_points_initial_si = np.zeros(shape=(stable_boundary_points_initial_pu.shape[0],3))
				stable_points_initial_si          = np.zeros(shape=(stable_points_initial_pu.shape[0]         ,3))
				unknown_points_initially_in_si    = np.zeros(shape=(unknown_points_initial_pu.shape[0]        ,3))
				stable_points_initial_si_OK       = np.zeros(shape=(stable_points_initial_pu_OK.shape[0]      ,3))
				stable_boundary_points_final_si   = np.zeros(shape=(stable_boundary_points_final_pu.shape[0]  ,3))
				stable_points_outside_final_si    = np.zeros(shape=(stable_points_outside_final_pu.shape[0]   ,3))

				#Conversions pu vers si
				for i in range(0,unknown_points_initial_pu.shape[0]):
					unknown_points_initially_in_si[i,:] = Conversion_pu_si(unknown_points_initial_pu[i,:], P_boundaries, Q_boundaries, U_boundaries)
				for i in range(0,stable_points_initial_pu_OK.shape[0]):
					stable_points_initial_si_OK[i,:]  = Conversion_pu_si(stable_points_initial_pu_OK[i,:], P_boundaries, Q_boundaries, U_boundaries)				
				for i in range(0,stable_boundary_points_initial_pu.shape[0]):
					stable_boundary_points_initial_si[i,:] = Conversion_pu_si(stable_boundary_points_initial_pu[i,:], P_boundaries, Q_boundaries, U_boundaries)		
				for i in range(0,stable_points_initial_pu.shape[0]):
					stable_points_initial_si[i,:] = Conversion_pu_si(stable_points_initial_pu[i,:], P_boundaries, Q_boundaries, U_boundaries)
				for i in range(0,stable_boundary_points_final_pu.shape[0]):
					stable_boundary_points_final_si[i,:]         = Conversion_pu_si(stable_boundary_points_final_pu[i,:], P_boundaries, Q_boundaries, U_boundaries)		
				for i in range(0,stable_points_outside_final_pu.shape[0]):
					stable_points_outside_final_si[i,:]         = Conversion_pu_si(stable_points_outside_final_pu[i,:], P_boundaries, Q_boundaries, U_boundaries)
				
				#recuperation des valeurs max
				max_status_stable = float('inf')
				max_status_unknown = float('inf')
				max_status_unstable = float('inf')
				if status_stable[:,1].shape[0]>0:
					max_status_stable =np.max(status_stable[:,1])
				if status_unknown[:,1].shape[0]>0:
					max_status_unknown =np.max(status_unknown[:,1])
				if status_unstable[:,1].shape[0]>0:
					max_status_unstable =np.max(status_unstable[:,1])				
				if stable_points_initial_pu.shape[0] >0 :
					domainIndicator[indDomain] =  (nb_stable_outside_after*1.0) / (stable_points_initial_pu.shape[0]*1.0)
					
				chosen=True
				if indDomain==0:
					stable_boundary_points_chosen_si = stable_boundary_points_final_si
					finalDomain=indDomain
				else:
					if domainIndicator[indDomain-1]>0.7 and domainIndicator[indDomain]<domainIndicator[indDomain-1] :
						stable_boundary_points_chosen_si = stable_boundary_points_final_si
						finalDomain=indDomain
					else:
						chosen=False
				
				#print pour le doc texte de sortie
				print 	"Domain type                          : ", indDomain , "\n" \
						"Final domain                         : ", finalDomain, "\n" \
						"Initially inside stable points       : ", stable_points_initial_pu.shape[0] , "\n" \
						"Initially inside unstable points     : ", unstable_points_initial_in_pu.shape[0] , "\n" \
						"Initially inside unknown points      : ", unknown_points_initial_pu.shape[0] , "\n" \
						"Finally outside stable points        : ", nb_stable_outside_after , "\n" \
						"Finally inside unstable points       : ", nb_unstable_inside_after , "\n" \
						"Finally inside unknown points        : ", nb_unknown_inside_after , "\n" \
						"Finally inside stable points (met. 1): ", stable_points_initial_pu_OK.shape[0] , "\n" \
						"Initial boundary points              : ", stable_points_initial_pu[ np.where(is_last_stable_point)[0], :].shape[0] , "\n" \
						"Intermediate boundary points         : ", initial_stable_boundary_points_pu.shape[0] , "\n" \
						"Final boundary points                : ", stable_boundary_points_final_si.shape[0] , "\n" \
						"Intermediate number of inequalities  : ", equation_reel_or.shape[0] , "\n" \
						"Final number of inequalities         : ", len(final_faces_pu) , "\n" \
						"Maximum equation mismatch in stable  : ", max_status_stable , "\n" \
						"Maximum equation mismatch in unknown : ", max_status_unknown , "\n" \
						"Maximum equation mismatch in unstable: ", max_status_unstable , "\n" \
						"Minimum mismatch of excluded stable  : ", min_excluded_stable_mismatch , "\n", \
						"Maximum mismatch of included unknown : ", max_included_unknown_mismatch , "\n", \
						"Maximum mismatch of included unstable: ", max_included_unstable_mismatch , "\n", \
						"Chosen:                              : ", chosen, "\n", \
						"\n"				
				print 	"[OL A]\t", \
						indDomain , "\t", \
						finalDomain , "\t", \
						stable_points_initial_pu.shape[0] , "\t", \
						unstable_points_initial_in_pu.shape[0] , "\t", \
						unknown_points_initial_pu.shape[0] , "\t", \
						nb_stable_outside_after , "\t", \
						nb_unstable_inside_after , "\t", \
						nb_unknown_inside_after , "\t", \
						stable_points_initial_pu_OK.shape[0] , "\t", \
						stable_points_initial_pu[ np.where(is_last_stable_point)[0], :].shape[0] , "\t", \
						initial_stable_boundary_points_pu.shape[0] , "\t", \
						stable_boundary_points_final_si.shape[0] , "\t", \
						equation_reel_or.shape[0] , "\t", \
						len(final_faces_pu) , "\t", \
						max_status_stable , "\t", \
						max_status_unknown , "\t", \
						max_status_unstable , "\t", \
						min_excluded_stable_mismatch , "\t", \
						max_included_unknown_mismatch , "\t", \
						max_included_unstable_mismatch , "\t", \
						chosen, "\t", \
						"\n"
				
				time_stop = time.time()
				print "[Elapsed time] One domain computation up to exports", (time_stop-time_start)
				time_start=time_stop
				
				# Export domain				
				if (stable_boundary_points_final_si.shape[0]>=4):
					CreateMachineDomain.FexportCSV(stable_boundary_points_final_si,"ampl_generators_domains_MC_" + str(indDomain),MachineRefName,MachineName,U_nominal,O)
					CreateMachineDomain.FconvexHullExport(stable_boundary_points_final_si,"final_convex_hull_MC" + str(indDomain))
				else:
					print "WARNING: final_convex_hull_MC is empty and not exported"
				
				if (visualisation == 1 or visualisation == 0):
					fig1 = plt.figure()
					ax1 = fig1.add_subplot(111, projection='3d')
					if unstable_points_initial_in_si.shape[0]>0:
						ax1.plot(unstable_points_initial_in_si[:,0],unstable_points_initial_in_si[:,1],unstable_points_initial_in_si[:,2], 'o', color="red")
					if unknown_points_initially_in_si.shape[0]>0:
						ax1.plot(unknown_points_initially_in_si[:,0] ,unknown_points_initially_in_si[:,1],unknown_points_initially_in_si[:,2], 'o', color="yellow")
					if stable_boundary_points_initial_si.shape[0]>0:
						ax1.plot(stable_boundary_points_initial_si[:,0]  ,stable_boundary_points_initial_si[:,1],stable_boundary_points_initial_si[:,2], 'o', color='green')

					#Compute initial hull in SI for display
					#Not needed, but useful to recover a hull object.
					try:
						hull = ConvexHull(stable_boundary_points_initial_si)
						for simplex in hull.simplices:
							ax1.plot(stable_boundary_points_initial_si[simplex,0], stable_boundary_points_initial_si[simplex,1], stable_boundary_points_initial_si[simplex,2], 'k-')
					except:
						print "ConvexHull call failed: vertices will not be drawn"
					
					ax1.set_xlabel('P', fontsize='xx-large')
					ax1.set_ylabel('Q', fontsize='xx-large')
					ax1.set_zlabel('U', fontsize='xx-large')
					fig1.suptitle(MachineName, fontsize='xx-large')
					print "Saving figure"
					fig1.savefig(MachineName + '_initial_MC_' + str(indDomain) + '.png')
					plt.draw()

					#Compute final hull in SI for display
					#Not needed, but useful to recover a hull object.
					fig2 = plt.figure()
					ax2 = fig2.add_subplot(111, projection='3d')					
					if stable_boundary_points_final_si.shape[0]>0:
						ax2.plot(stable_boundary_points_final_si[:,0],stable_boundary_points_final_si[:,1],stable_boundary_points_final_si[:,2], 'o', color="green")
					if stable_points_outside_final_si.shape[0]>0:
						ax2.plot(stable_points_outside_final_si[:,0]  ,stable_points_outside_final_si[:,1],stable_points_outside_final_si[:,2], 'o', color='red')

					try:
						hull = ConvexHull(stable_boundary_points_final_si)
						for simplex in hull.simplices:
							ax2.plot(stable_boundary_points_final_si[simplex,0], stable_boundary_points_final_si[simplex,1], stable_boundary_points_final_si[simplex,2], 'k-')
					except:
						print "ConvexHull call failed: vertices will not be drawn"
					
					ax2.set_xlabel('P', fontsize='xx-large')
					ax2.set_ylabel('Q', fontsize='xx-large')
					ax2.set_zlabel('U', fontsize='xx-large')
					fig2.suptitle(MachineName, fontsize='xx-large')
					fig2.savefig(MachineName + '_final_MC_' + str(indDomain) + '.png')

					plt.draw()
			
				if (stable_points_initial_si.shape[0] > 0):
					CreateMachineDomain.FexportCSV(stable_points_initial_si,"ampl_generators_domains_MC_initial",MachineRefName,MachineName,U_nominal,O)
					CreateMachineDomain.FconvexHullExport(stable_points_initial_si,"initial_convex_hull_MC")
				else:
					print "WARNING: initial_convex_hull_MC is empty and not exported"
				
				# Export final domain
				print "Final domain: ", finalDomain
				if (stable_boundary_points_chosen_si.shape[0]>=4):
					CreateMachineDomain.FexportCSV(stable_boundary_points_chosen_si,"generators_domains_MC_"+MachineName,MachineRefName,MachineName,U_nominal,O)
					CreateMachineDomain.FconvexHullExport(stable_boundary_points_chosen_si,"final_convex_hull_MC")
				else:
					print "WARNING: final_convex_hull_MC is empty and not exported"
				
				time_stop = time.time()
				print "[Elapsed time] One domain computation ", (time_stop-time_start)
				time_start=time_stop
			else:
				print "[OL A]\tWarning: no convex hull to compute because stable_points_initial_pu is empty"

	else:
		print "Only version 1 implemented here"
	
if __name__ == '__main__':	
	try:
		parser = argparse.ArgumentParser(description='Compute stable simulation domain for generator in folder. To run the program, you must be first be inside the simulation directory and run "python ..\MachineStableDomainSearch.py + arguments"')
		parser.add_argument('-v','--version', help='which version of the program to be run : - 0 Simple, - 1 Random, - 3 Criteria,  4 - Simple+',
				 required=True)
		parser.add_argument('-i','--image', help='switch visualization on or off (0 off, 1 on)',
				 required=True)
		parser.add_argument('-d','--directions', help='Chose number of points to create the domain (between 20000 and 50000)',
				 required=True)
		parser.add_argument('-n','--nonneg', action="store_true", help='constrain the domain with P > 0 when used',
				 required=False)				 
		args = parser.parse_args()

		time_start = time.time()
		
		if (args.nonneg):
			main(int(args.version), int(args.image), int(args.directions), True)
		else :
			main(int(args.version), int(args.image), int(args.directions), False)

		time_elapsed = (time.time() - time_start)
		print "[Elapsed time] Overall computation time", time_elapsed

		if (int(args.image) == 1):
			plt.show()
			
	finally:
		print "finalize() step commented"
		l.finalize() 	